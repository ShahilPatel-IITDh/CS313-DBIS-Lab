/* Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* ====================================================================
 * prunsrv -- Service Runner.
 * Contributed by Mladen Turk <mturk@apache.org>
 * 05 Aug 2003
 * ====================================================================
 */

/* Force the JNI vprintf functions */
#define _DEBUG_JNI  1
#include "apxwin.h"
#include "private.h"
#include "prunsrv.h"

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <fcntl.h>
#include <io.h>         /* _open_osfhandle */
#include <share.h>

#ifndef  MIN
#define  MIN(a,b)    (((a)<(b)) ? (a) : (b))
#endif

#define STDIN_FILENO  0
#define STDOUT_FILENO 1
#define STDERR_FILENO 2
#define ONE_MINUTE    (60 * 1000)

#ifdef _WIN64
#define KREG_WOW6432  KEY_WOW64_32KEY
#define PRG_BITS      64
#else
#define KREG_WOW6432  0
#define PRG_BITS      32
#endif

typedef struct APX_STDWRAP {
    LPCWSTR szLogPath;
    LPCWSTR szStdOutFilename;
    LPCWSTR szStdErrFilename;
    FILE   *fpStdOutFile;
    FILE   *fpStdErrFile;
} APX_STDWRAP;

/* Use static variables instead of #defines */
static LPCWSTR  PRSRV_AUTO        = L"auto";
static LPCWSTR  PRSRV_JAVA        = L"java";
static LPCWSTR  PRSRV_JVM         = L"jvm";
static LPCWSTR  PRSRV_JDK         = L"jdk";
static LPCWSTR  PRSRV_JRE         = L"jre";
static LPCWSTR  PRSRV_DELAYED     = L"delayed";
static LPCWSTR  PRSRV_MANUAL      = L"manual";
static LPCWSTR  PRSRV_JBIN        = L"\\bin\\java.exe";
static LPCWSTR  PRSRV_PBIN        = L"\\bin";
static LPCWSTR  PRSRV_SIGNAL      = L"SIGNAL";
static LPCWSTR  PRSV_JVMOPTS9     = L"JDK_JAVA_OPTIONS=";
static LPCWSTR  STYPE_INTERACTIVE = L"interactive";

static LPWSTR       _service_name = NULL;
/* Allowed procrun commands */
static LPCWSTR _commands[] = {
    L"TS",      /*  1 Run Service as console application (default)*/
    L"RS",      /*  2 Run Service */
    L"ES",      /*  3 Execute start */
    L"SS",      /*  4 Stop Service */
    L"US",      /*  5 Update Service parameters */
    L"IS",      /*  6 Install Service */
    L"DS",      /*  7 Delete Service */
    L"PS",      /*  8 Print Service Configuration */
    L"?",       /*  9 Help */
    L"VS",      /* 10 Version */
    NULL
};

static LPCWSTR _altcmds[] = {
    L"run",         /*  1 Run Service as console application (default)*/
    L"service",     /*  2 Run Service */
    L"start",       /*  3 Start Service */
    L"stop",        /*  4 Stop Service */
    L"update",      /*  5 Update Service parameters */
    L"install",     /*  6 Install Service */
    L"delete",      /*  7 Delete Service */
	L"print",       /*  8 Print Service Configuration */
    L"help",        /*  9 Help */
    L"version",     /* 10 Version */
    NULL
};

/* Allowed procrun parameters */
static APXCMDLINEOPT _options[] = {

/* 0  */    { L"Description",       L"Description",     NULL,           APXCMDOPT_STR | APXCMDOPT_SRV, NULL, 0},
/* 1  */    { L"DisplayName",       L"DisplayName",     NULL,           APXCMDOPT_STR | APXCMDOPT_SRV, NULL, 0},
/* 2  */    { L"Install",           L"ImagePath",       NULL,           APXCMDOPT_STE | APXCMDOPT_SRV, NULL, 0},
/* 3  */    { L"ServiceUser",       L"ServiceUser",     NULL,           APXCMDOPT_STR | APXCMDOPT_SRV, NULL, 0},
/* 4  */    { L"ServicePassword",   L"ServicePassword", NULL,           APXCMDOPT_STR | APXCMDOPT_SRV, NULL, 0},
/* 5  */    { L"Startup",           L"Startup",         NULL,           APXCMDOPT_STR | APXCMDOPT_SRV, NULL, 0},
/* 6  */    { L"Type",              L"Type",            NULL,           APXCMDOPT_STR | APXCMDOPT_SRV, NULL, 0},

/* 7  */    { L"DependsOn",         L"DependsOn",       NULL,           APXCMDOPT_MSZ | APXCMDOPT_REG, NULL, 0},
/* 8  */    { L"Environment",       L"Environment",     NULL,           APXCMDOPT_MSZ | APXCMDOPT_REG, NULL, 0},
/* 9  */    { L"User",              L"User",            NULL,           APXCMDOPT_STR | APXCMDOPT_REG, NULL, 0},
/* 10 */    { L"Password",          L"Password",        NULL,           APXCMDOPT_BIN | APXCMDOPT_REG, NULL, 0},
/* 11 */    { L"LibraryPath",       L"LibraryPath",     NULL,           APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},

/* 12 */    { L"JavaHome",          L"JavaHome",        L"Java",        APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},
/* 13 */    { L"Jvm",               L"Jvm",             L"Java",        APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},
/* 14 */    { L"JvmOptions",        L"Options",         L"Java",        APXCMDOPT_MSZ | APXCMDOPT_REG, NULL, 0},
/* 15 */    { L"JvmOptions9",       L"Options9",        L"Java",        APXCMDOPT_MSZ | APXCMDOPT_REG, NULL, 0},
/* 16 */    { L"Classpath",         L"Classpath",       L"Java",        APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},
/* 17 */    { L"JvmMs",             L"JvmMs",           L"Java",        APXCMDOPT_INT | APXCMDOPT_REG, NULL, 0},
/* 18 */    { L"JvmMx",             L"JvmMx",           L"Java",        APXCMDOPT_INT | APXCMDOPT_REG, NULL, 0},
/* 19 */    { L"JvmSs",             L"JvmSs",           L"Java",        APXCMDOPT_INT | APXCMDOPT_REG, NULL, 0},

/* 20 */    { L"StopImage",         L"Image",           L"Stop",        APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},
/* 21 */    { L"StopPath",          L"WorkingPath",     L"Stop",        APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},
/* 22 */    { L"StopClass",         L"Class",           L"Stop",        APXCMDOPT_STR | APXCMDOPT_REG, NULL, 0},
/* 23 */    { L"StopParams",        L"Params",          L"Stop",        APXCMDOPT_MSZ | APXCMDOPT_REG, NULL, 0},
/* 24 */    { L"StopMethod",        L"Method",          L"Stop",        APXCMDOPT_STR | APXCMDOPT_REG, NULL, 0},
/* 25 */    { L"StopMode",          L"Mode",            L"Stop",        APXCMDOPT_STR | APXCMDOPT_REG, NULL, 0},
/* 26 */    { L"StopTimeout",       L"Timeout",         L"Stop",        APXCMDOPT_INT | APXCMDOPT_REG, NULL, 0},

/* 27 */    { L"StartImage",        L"Image",           L"Start",       APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},
/* 28 */    { L"StartPath",         L"WorkingPath",     L"Start",       APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},
/* 29 */    { L"StartClass",        L"Class",           L"Start",       APXCMDOPT_STR | APXCMDOPT_REG, NULL, 0},
/* 30 */    { L"StartParams",       L"Params",          L"Start",       APXCMDOPT_MSZ | APXCMDOPT_REG, NULL, 0},
/* 31 */    { L"StartMethod",       L"Method",          L"Start",       APXCMDOPT_STR | APXCMDOPT_REG, NULL, 0},
/* 32 */    { L"StartMode",         L"Mode",            L"Start",       APXCMDOPT_STR | APXCMDOPT_REG, NULL, 0},

/* 33 */    { L"LogPath",           L"Path",            L"Log",         APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},
/* 34 */    { L"LogPrefix",         L"Prefix",          L"Log",         APXCMDOPT_STR | APXCMDOPT_REG, NULL, 0},
/* 35 */    { L"LogLevel",          L"Level",           L"Log",         APXCMDOPT_STR | APXCMDOPT_REG, NULL, 0},
/* 36 */    { L"StdError",          L"StdError",        L"Log",         APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},
/* 37 */    { L"StdOutput",         L"StdOutput",       L"Log",         APXCMDOPT_STE | APXCMDOPT_REG, NULL, 0},
/* 38 */    { L"LogJniMessages",    L"LogJniMessages",  L"Log",         APXCMDOPT_INT | APXCMDOPT_REG, NULL, 1},
/* 39 */    { L"PidFile",           L"PidFile",         L"Log",         APXCMDOPT_STR | APXCMDOPT_REG, NULL, 0},
/* 40 */    { L"Rotate",            L"Rotate",          L"Log",         APXCMDOPT_INT | APXCMDOPT_REG, NULL, 0},
            /* NULL terminate the array */
            { NULL }
};

#define GET_OPT_V(x)  _options[x].szValue
#define GET_OPT_I(x)  _options[x].dwValue
#define GET_OPT_T(x)  _options[x].dwType

#define ST_DESCRIPTION      GET_OPT_T(0)
#define ST_DISPLAYNAME      GET_OPT_T(1)
#define ST_INSTALL          GET_OPT_T(2)
#define ST_SUSER            GET_OPT_T(3)
#define ST_SPASSWORD        GET_OPT_T(4)
#define ST_STARTUP          GET_OPT_T(5)
#define ST_TYPE             GET_OPT_T(6)

#define SO_DESCRIPTION      GET_OPT_V(0)
#define SO_DISPLAYNAME      GET_OPT_V(1)
#define SO_INSTALL          GET_OPT_V(2)
#define SO_SUSER            GET_OPT_V(3)
#define SO_SPASSWORD        GET_OPT_V(4)
#define SO_STARTUP          GET_OPT_V(5)
#define SO_TYPE             GET_OPT_V(6)

#define SO_DEPENDSON        GET_OPT_V(7)
#define SO_ENVIRONMENT      GET_OPT_V(8)

#define SO_USER             GET_OPT_V(9)
#define SO_PASSWORD         GET_OPT_V(10)
#define SO_LIBPATH          GET_OPT_V(11)

#define SO_JAVAHOME         GET_OPT_V(12)
#define SO_JVM              GET_OPT_V(13)
#define SO_JVMOPTIONS       GET_OPT_V(14)
#define SO_JVMOPTIONS9      GET_OPT_V(15)
#define SO_CLASSPATH        GET_OPT_V(16)
#define SO_JVMMS            GET_OPT_I(17)
#define SO_JVMMX            GET_OPT_I(18)
#define SO_JVMSS            GET_OPT_I(19)

#define SO_STOPIMAGE        GET_OPT_V(20)
#define SO_STOPPATH         GET_OPT_V(21)
#define SO_STOPCLASS        GET_OPT_V(22)
#define SO_STOPPARAMS       GET_OPT_V(23)
#define SO_STOPMETHOD       GET_OPT_V(24)
#define SO_STOPMODE         GET_OPT_V(25)
#define SO_STOPTIMEOUT      GET_OPT_I(26)

#define SO_STARTIMAGE       GET_OPT_V(27)
#define SO_STARTPATH        GET_OPT_V(28)
#define SO_STARTCLASS       GET_OPT_V(29)
#define SO_STARTPARAMS      GET_OPT_V(30)
#define SO_STARTMETHOD      GET_OPT_V(31)
#define SO_STARTMODE        GET_OPT_V(32)

#define SO_LOGPATH          GET_OPT_V(33)
#define SO_LOGPREFIX        GET_OPT_V(34)
#define SO_LOGLEVEL         GET_OPT_V(35)

#define SO_STDERROR         GET_OPT_V(36)
#define SO_STDOUTPUT        GET_OPT_V(37)
#define SO_JNIVFPRINTF      GET_OPT_I(38)
#define SO_PIDFILE          GET_OPT_V(39)
#define SO_LOGROTATE        GET_OPT_I(40)

static SERVICE_STATUS        _service_status;
static SERVICE_STATUS_HANDLE _service_status_handle = NULL;
/* Set if launched by SCM   */
static BOOL                  _service_mode = FALSE;
/* JVM used as worker       */
static BOOL                  _jni_startup  = FALSE;
/* JVM used for shutdown    */
static BOOL                  _jni_shutdown = FALSE;
/* Java used as worker       */
static BOOL                  _java_startup  = FALSE;
/* Java used for shutdown    */
static BOOL                  _java_shutdown = FALSE;
/* Global variables and objects */
static APXHANDLE    gPool;
static APXHANDLE    gWorker;
static APX_STDWRAP  gStdwrap;           /* stdio/stderr redirection */
static int          gExitval;
static LPWSTR       gStartPath;

static LPWSTR   _jni_jvmpath              = NULL;   /* Path to jvm dll */
static LPSTR    _jni_jvmoptions           = NULL;   /* jvm options */
static LPSTR    _jni_jvmoptions9          = NULL;   /* java 9+ options */

static LPSTR    _jni_classpath            = NULL;
static LPCWSTR  _jni_rparam               = NULL;    /* Startup  arguments */
static LPCWSTR  _jni_sparam               = NULL;    /* Shutdown arguments */
static LPSTR    _jni_rmethod              = NULL;    /* Startup  method */
static LPSTR    _jni_smethod              = NULL;    /* Shutdown method */
static LPSTR    _jni_rclass               = NULL;    /* Startup  class */
static LPSTR    _jni_sclass               = NULL;    /* Shutdown class */
static HANDLE gShutdownEvent = NULL;
static HANDLE gSignalEvent   = NULL;
static HANDLE gSignalThread  = NULL;
static HANDLE gPidfileHandle = NULL;
static LPWSTR gPidfileName   = NULL;
static BOOL   gSignalValid   = TRUE;
static APXJAVA_THREADARGS gRargs;
static APXJAVA_THREADARGS gSargs;

DWORD WINAPI eventThread(LPVOID lpParam)
{
    DWORD dwRotateCnt = SO_LOGROTATE;

    for (;;) {
        DWORD dw = WaitForSingleObject(gSignalEvent, 1000);
        if (dw == WAIT_TIMEOUT) {
            /* Do process maintenance */
            if (SO_LOGROTATE != 0 && --dwRotateCnt == 0) {
                /* Perform log rotation. */

                 dwRotateCnt = SO_LOGROTATE;
            }
            continue;
        }
        if (dw == WAIT_OBJECT_0 && gSignalValid) {
            if (!GenerateConsoleCtrlEvent(CTRL_BREAK_EVENT, 0)) {
                /* Invoke Thread dump */
                if (gWorker && _jni_startup)
                    apxJavaDumpAllStacks(gWorker);
            }
            ResetEvent(gSignalEvent);
            continue;
        }
        break;
    }
    ExitThread(0);
    return 0;
    UNREFERENCED_PARAMETER(lpParam);
}

/* redirect console stdout/stderr to files
 * so that Java messages can get logged
 * If stderrfile is not specified it will
 * go to stdoutfile.
 */
static BOOL redirectStdStreams(APX_STDWRAP *lpWrapper, LPAPXCMDLINE lpCmdline)
{
    BOOL aErr = FALSE;
    BOOL aOut = FALSE;

    /* Allocate console if we have none
     */
    if (GetConsoleWindow() == NULL) {
        HWND hc;
        AllocConsole();
        if ((hc = GetConsoleWindow()) != NULL)
            ShowWindow(hc, SW_HIDE);
    }
    /* redirect to file or console */
    if (lpWrapper->szStdOutFilename) {
        if (lstrcmpiW(lpWrapper->szStdOutFilename, PRSRV_AUTO) == 0) {
            WCHAR lsn[1024];
            aOut = TRUE;
            lstrlcpyW(lsn, 1020, lpCmdline->szApplication);
            lstrlcatW(lsn, 1020, L"-stdout");
            lstrlocaseW(lsn);
            lpWrapper->szStdOutFilename = apxLogFile(gPool,
                                                     lpWrapper->szLogPath,
                                                     lsn,
                                                     NULL, TRUE,
                                                     SO_LOGROTATE);
        }
        /* Delete the file if not in append mode
         * XXX: See if we can use the params instead of that.
         */
        if (!aOut)
            DeleteFileW(lpWrapper->szStdOutFilename);
        if ((lpWrapper->fpStdOutFile = _wfsopen(lpWrapper->szStdOutFilename,
                                               L"a",
                                               _SH_DENYNO))) {
            _dup2(_fileno(lpWrapper->fpStdOutFile), 1);
            *stdout = *lpWrapper->fpStdOutFile;
            setvbuf(stdout, NULL, _IONBF, 0);
        }
        else {
            lpWrapper->szStdOutFilename = NULL;
        }
    }
    if (lpWrapper->szStdErrFilename) {
        if (lstrcmpiW(lpWrapper->szStdErrFilename, PRSRV_AUTO) == 0) {
            WCHAR lsn[1024];
            aErr = TRUE;
            lstrlcpyW(lsn, 1020, lpCmdline->szApplication);
            lstrlcatW(lsn, 1020, L"-stderr");
            lstrlocaseW(lsn);
            lpWrapper->szStdErrFilename = apxLogFile(gPool,
                                                     lpWrapper->szLogPath,
                                                     lsn,
                                                     NULL, TRUE,
                                                     SO_LOGROTATE);
        }
        if (!aErr)
            DeleteFileW(lpWrapper->szStdErrFilename);
        if ((lpWrapper->fpStdErrFile = _wfsopen(lpWrapper->szStdErrFilename,
                                               L"a",
                                               _SH_DENYNO))) {
            _dup2(_fileno(lpWrapper->fpStdErrFile), 2);
            *stderr = *lpWrapper->fpStdErrFile;
            setvbuf(stderr, NULL, _IONBF, 0);
        }
        else {
            lpWrapper->szStdOutFilename = NULL;
        }
    }
    else if (lpWrapper->fpStdOutFile) {
        _dup2(_fileno(lpWrapper->fpStdOutFile), 2);
        *stderr = *lpWrapper->fpStdOutFile;
         setvbuf(stderr, NULL, _IONBF, 0);
    }
    return TRUE;
}

/* Prints usage. */
static void printUsage(LPAPXCMDLINE lpCmdline, BOOL isHelp)
{
    int i = 0;
    fwprintf(stderr, L"Usage: %s command [ServiceName] [--options]\n",
             lpCmdline->szExecutable);
    fwprintf(stderr, L"  Commands:\n");
    if (isHelp)
        fwprintf(stderr, L"  help                   This page\n");
    fwprintf(stderr, L"  install [ServiceName]  Install Service\n");
    fwprintf(stderr, L"  update  [ServiceName]  Update Service parameters\n");
    fwprintf(stderr, L"  delete  [ServiceName]  Delete Service\n");
    fwprintf(stderr, L"  start   [ServiceName]  Start Service\n");
    fwprintf(stderr, L"  stop    [ServiceName]  Stop Service\n");
    fwprintf(stderr, L"  run     [ServiceName]  Run Service as console application\n");
    fwprintf(stderr, L"  print   [ServiceName]  Display the command to (re-)create the current configuration\n");
    fwprintf(stderr, L"  pause   [Num Seconds]  Sleep for n Seconds (defaults to 60)\n");
    fwprintf(stderr, L"  version                Display version\n");
    fwprintf(stderr, L"  Options:\n");
    while (_options[i].szName) {
        fwprintf(stderr, L"  --%s\n", _options[i].szName);
        ++i;
    }
}

/* Prints version. */
static void printVersion(void)
{
    fwprintf(stderr, L"Apache Commons Daemon Service Runner version %S/Win%d (%S)\n",
            PRG_VERSION, PRG_BITS, __DATE__);
    fwprintf(stderr, L"Copyright (c) 2000-2022 The Apache Software Foundation.\n\n"
                     L"For bug reporting instructions, please see:\n"
                     L"<URL:https://issues.apache.org/jira/browse/DAEMON>.");
}

/* Displays comamnd line parameters. */
static void dumpCmdline()
{
    int i = 0;
    while (_options[i].szName) {
        if (_options[i].dwType & APXCMDOPT_INT)
            fwprintf(stderr, L"--%-16s %d\n", _options[i].szName,
                     _options[i].dwValue);
        else if (_options[i].szValue)
            fwprintf(stderr, L"--%-16s %s\n", _options[i].szName,
                     _options[i].szValue);
        else
            fwprintf(stderr, L"--%-16s <NULL>\n", _options[i].szName);
        ++i;
    }
}

// TODO: Figure out a way to move apxSetInprocEnvironment from here and
// prunmgr.c to utils.c
void apxSetInprocEnvironment()
{
    LPWSTR p, e;
    HMODULE hmodUcrt;
    WPUTENV wputenv_ucrt = NULL;

    if (!SO_ENVIRONMENT)
        return;    /* Nothing to do */

    hmodUcrt = LoadLibraryExA("ucrtbase.dll", NULL, LOAD_LIBRARY_SEARCH_SYSTEM32);
    if (hmodUcrt != NULL) {
        wputenv_ucrt =  (WPUTENV) GetProcAddress(hmodUcrt, "_wputenv");
    }

    for (p = SO_ENVIRONMENT; *p; p++) {
        e = apxExpandStrW(gPool, p);
        _wputenv(e);
        if (wputenv_ucrt != NULL) {
            wputenv_ucrt(e);
        }
        apxFree(e);
        while (*LL;    /* Shutdosee:\n"
           /* Perform lo 0jUcrt prunsrv -- Service Runner.
 * NMicrosoftatic APXCMDLINEOPT    [SerSr
    }
4 L"ES",ileno(lpWrapper->fpStdErrFile), 2);
            *stderr = *lpWrapper->fpStdErrFSr
    }
4 L"""""""""lllllll    ion="6see:\n"
 1zLengthW(        *s, &c)ase.dll", NULLc_SEARCH_SYSTEM32);lstrcmpiW(lRKDIR)*/
            P    EClllNt  APXCMDwprintf(s!" ifapperrFil_t()
{
    LPWST(stderr, L"  install [SXCMDLINEOPtk    6s %s\n, "_uRMealL a0jU)v WWL
     "_uRMealL a0jU)v WWL
     "_uRMealL a0jU)v WWL
     "_uRMealL a0jU)v WWL
     PPPPPPPerform l(ASF) under one or more
m4P  /* Shutdosee:\n"
           /* Perform lo 0jUcrt prunsrv -- Service RunnO: FigureE | APXCMDOPT_REG, NULL, 0},
/* 37 -- Service R6         :D lC- Se        version  s -- Service R6   D
statetInprocEnvironment()
JF   5ey        wputenv_ucrt(e);
        }
        apxFree(e);
        while (*LL;    /* Shutdosee:\n"
           /* Perform lo 0jUcrt prunsrv -- Service Runner.
 * NMicrosoftatic APXCMDLINEOPT    [SerSr
    }
4 L"ES",ileno(lpWrappr.
 * NeSta}Sefine IDLWWLIaticemprtrlocasekMV_AUTO)Mte_Aa.
 * NeSta}S .Tpperne IDLWWLIwrappr.}Lns:\n");
ters */ prunsrv -- Serv=rtde}rne IDLWdliARTMODE        GET_OPT_V(32)

#define MODE        GET_LPAPXCMDLINE lpCmdl IDLWW ,oMeP(              isHelp)
{
R   }
            s l(5)
#define SO_NE lpCmdl IDLWW ,oMeP( 00
#define Ine IDC_pGelp)
        fwprintf(stderr,T_REG, NULL, o
/* Displays comamnd line parameters. */
static void dumpCm LoadLibraryExA("ucrtbase.dll", NULL, LOAD_LIBRARY_SEARCH_SYSTEM32);
    if (hmodUcrtline, BOOL isHelp)
{oL"Mode",e MODE        GET_LPAPXi _OPT_ance wA("ucrtbase.dll", NU   *stdout = *lpWrapper->fpStdOutFile;
            setvbuf(stdout, NULL, _IONBF, 0&}
    }
    if (lpWrapper->szStdErr              /* S:"
BUILDLOC = $(PREFIX)\amd64             {
    BOOL pIeno(lpWrapper->fpS[SerSr
    }
4 L"ES",ileno(lpWrappr.
}
 );
    ",ilenoES",}nv_ucrt(e);
\n");r  LPWSTR   <V"_uRMealL a0jU)v WWLl", NU   *stdout = *lp      z  <V"_uRMealL a0jpcLIwra&& _jni_startup)_PPSLC   NeSta}R
      ealL a0jU, 2);
            *stderrv2y_
static APXJAVA_THREADAR,enseiceName]  StarLOC = $(PREh"JvmOptionsiWrappr.  /* ieFFFFFFFFFFFFFFFFFFFFFFFFFFF7h setvbuf(stdout, NULL, _IONBF, 0&}
    }
        L"<URL:el",eSu
#includsFFFFFFF         lpWrapper->szLogPath,
                                        SDeFFLns:v_jni_st8aorLOCSDeF_r6:v_jni_st8aorLOCSDeF_r6:v_jni_st8OCSDeF_r6:v_jni_st8OCNM    ",ilenoES",   = NULL;    /* 
{oL"Mode",e MODE     v   oLL;  _DC_pGelp)
     SbDC_pGelp)
     SbDRe]  Display the ci            v   oLL;  _DC_pGelp)
     SbDC_pGelp)
 rap4Iwra&& _jni_startup)_PPSLC   NeSta}R
      ealL a0jU, 2);
            *stderrv2y_
static:#deLRtf2y_(v_LOGROTAT
 rrLOC = $(PREh"JvmOptionsiWrappr.  /* ieFFn        whiLL;  _DC_pG(PREh"JvmLL;  _DCptionsiWrappr.  /* ieFFnGuvJV applica-) {
        fwprin/  }
  3  }
4 L"""""mmmmd       _pGelp)
     SbDC_pGelBl:      4
 (ek T_pGelBl:}
 );
    ",ilenoESAlBlJV applica-z}
   6s %s4	ROTAT
 rrLOC = $(PREh"JvmOptionsiWrappr.  /* ieFFn wpriniTGelBl:      APANY }                              
     bpsc _jni_startup)_PPSLC   NeSta}R
      ealL a0jU, 2);
            *stderri8OCN /* ies8           
     ni3(i  ",ilen         *stderri8aOerS     ealL a   CSDeF_r elBl:     o" except in comm        r"icense.  You m_AUTO)Mtcbhd'%
        while (*LL;    /* ShutdosecTNULL;
static LPWSTR gPidfileName     *s    ",ilenoNuO)Mtci P_pGe-2
static LPWS LPWSTR gPidfileName     *s    ",ilenoNuO)Mtci P_pGe-2
static LPWS LPWSTR gPidfileName     *s    ",ilenoNuO)Mtci P_pGe-2
static LPWS LPWSTR gPidfileName     *s    ",ilenoNuO)Mtci P_pGe-2
s       _jni_startup)_PPper- thePSTR  ",ilenoNuO)3oNuOhePSTR  ",ileath,
       "ic LPWS LPWSTR gPidfileName     *s    ",ilenoNuO)Mtci P_pGe-2
static LPWS LPWSTR gPidfileName     *s    ",ilenoNuO)Mtci P_pGe-2
  ",ilenoNuO)Mtci : ",ilenoNuO)3oNuOhePSTR  ",ieName     *s    ",C ies8           
  _STR | APXCMDOPT_SMHMtci P_pGe-2
n83)
#define ST_Sn        )Mtci P_pGe-2
static LPWS LPWSTR gPidfileName     *s  c            *stderrv2y_
static"aPper- thePSTR  ug 2)32.1_
staticenG2.1_
staticenG2.1_
staticenG2.1_
stat.1_
staticenG2.1_
staticNt>(OIatderri8f gPidfwhile (e Apache Sofy_
staticus    ",ticNt>(OIatderri8f gPidfwhile (e Apache Sofy_
staticus    "tci PGI LPWS LPWSTR gPidfileName     *s  c            *stderrv2y_
static"aPper- thePSTR  ug 2)32.1_
staticenG2.1_
staticenG2.1_
staticenG2.1_
stat.1_
staticenG2.1_
staticNt>(OIatderri8     G2.1_
staticNt>oApachogPath,
         APXCMDOP_ee._
staticenG2.  "tci ic LPWS LPWSTR gr    whiLLPt>(OIat gr    wv -- Service Wf    *s  c            *stderrv2yatismcm        r"tderrv2 L
sta  *stderrv2y_
stne paranMb-Pci P_pGe-2TTbhd'%
 TION      GET_OPT_T(0)
#defin TION      GET_OPTasspath         le or c>:schemas-ic"aPper- thjP7M      *stderrv2y        /* NULL terminate the arr
      staf (!chemas-ic"aPper- thjP7M      *stderrv2ydfileName     *sIa el",          fOn",       NULL,           APXCMDOPT_MSZ | APXCMDOPT_Filenamtderrv2y_
static"aPper- thePSTR  ug 2)32.1_
staticenG2.1_
staticenG2.1_
staticenG2.1_
stat.1_
staticenG2.1_
staticNt>(OIatderri8     G2.1tatiNX=n+4 L"""""mmmmd     rri8     Sf3)
#define ST_Sn        )Mtci P_pGe-2
statitci P_pGe-2    Gtativer-ena'   /* Sr+)Mte_Aa.
 * NeSta}S .Tpperne 9C3\_Aa.
 * NeSta}S .Tpperne 9C3\_Aa.
 * NeSta}S .Tppen",       NULL,           APXCMDOPT_MSZ"Mo print   [ServiceName]  eeeeeeeeeeeeeeeeeeeeeeee(e Apache Sofy_
stati37 -- Service R6         :D lC- Se        version  s -- Service R6   =rdL
 *dfileName     *sIa el",          fOn", *s | APXMo rough= FALSE;
   On",Environment()
JF   5ey        wputenv
      Fc  pache Sofy_
s  Fc  MDOrt(e);
        }
        apxFrGe-  L"P_pGe-2atic H    )Mtc: P_pGe-2
statita-z}
   6s %s4!rt(e);
        }
        apxFrperne               _SH_DENt(e);
        }
        apxFrh"Jle (*LL;    /* Shutdo* NeSta}S .Tpperne MDOPT_int   [S.TpS.  ngW /* Sr+)Mtr, L"  --%s\n", _options[i].szName);
        ++i;
    Sofy_
s  Fc  r, L"  --%s\n", _options[i].szName);
        ++i;
    Sofy_
s* NeSta}S .TppSubrvir, L"  --%s\n", _options[i].szName);
        ++i;
    Sofy_
s* NeSta}S .Tpp* Sr+)Mte     *s    ",ilenoNuO)Mtci P_]  Display the ci     *lpWrapper->fpStdOutFile* NeSta}S .Tpperne M&&ENt(e);
        }
        apxFrh"Eile (*LL;    /* ShutdoooooPREh"Jvmxp  if (lpWrapper->szStdEr* NeSta}S .Tpperne IDLWWLIwraper->fpStdOutFilemxp !=r* NeSta}S .Tpperne I, L"  --%s\n", _options[i]    "tci* NeSta}S .Tpperne IDLWWLIwraper->fpStdOut* NeSta}S .Tpperne MDOmxpDLWWLIwraper->fpStgPidfileName   gPidfileName   c APXCMDLINEOPT    [S   }
        apxFree(ee (*LL;    /* Shutdo* NeSta}S .T.
 * NMDOPT_int   [S.TpNumberW /* Sr+)Mtr, L"  --%s\n", _options[i].szName);
        ++i;
    Sofy_
s  Fc  r, L"  --%s\n", _options[i].szName);
        ++i;
    Sofy_
s* NeSta}S .TppSubrvir, L"  --%s\n", _options[i].szName);
        ++i;
    Sofy_
s* NeSta}S .Tpp* Sr+)Mte     *s        gPidfileName   c APXCMDLINEOPT    [S   }
        apxFrMSZle (*LL;    /* Shutdo* NeSta}S .Tpperne MDOPT_int   [S.TpMzper->/* Sr+)Mtr, L"  --%s\n", _options[i].szName);
        ++i;
    Sofy_
  Fc  r, L"  --%s\n", _options[i].szName);
        ++i;
    Sofy_
* NeSta}S .TppSubrvir, L"  --%s\n", _options[i].szName);
        ++i;
    Sofy_
* NeSta}S .Tpp* Sr+)Mtr, L"  --%s\n", _options[i].szName);
        ++i;
    Sofy_
    i, L"  --%s\n", _options[i].szName);
        ++i;
    Sofy_
&(rvice Runner.
 * NMe     *s        gPidfileNamf(stderr, NULLMerge           wp R6   FALSE; L"\          *lpWrapper->c APXCMDLINEOPT    [S   }
        apxFrADDle (*LL;    /* ShPREh"Jvcv =r* NeSta}S .Tpperne ;(*LL;    /* ShPREh"Jvovt i = 0;
    whilllllCMDLINEOPT    [S   }
        apxFrMSZle (*LL;    /* Shutdoovt iPT_int   [S.TpMzper->/* Sr+)Mtr
  Fc  r, L"  --%s\n", _options[i].szName);
       * NeSta}S .TppSubrvir, L"  --%s\n", _options[i].szName);
       * NeSta}S .Tpp* Sr+)Mtr, L"  --%s\n", _options[i].szName);
           i, L"  --%s\n", _options[i].szName);
       &(rvice Runner.
 * NMe     *s            * NeSta}S .Tpperne MDOPT_    ealComb- SeszStdErov,vcvi, L"  --%s\n", _options[i].szName);
        ++i;
    Sof&(rvice Runner.
 * NMe     *s            CMDLovstdout, NULL, _IONBF, 0); "tciovs     *s        gPidfileNamf(stderr, N

#define MOF, 0);ClosPool,
 /* Sr+)Mte;ion */
  .1_
sMOF, 0ion  s -- Ser;APXCMDLINEF, 0options[i].szValue)
 Sav(lsnhangr"tvice Wf    *s (OI          L
sta  *stderrv2y_sav(e paranMb-Pci P_pGe-2TTbhd'%
 TION      GET_OPT_T(0)
#defin TION      GET_OPTasspat   GSZ | APXCMDOPT_Filenamtderrv2y_
static"aPpWRI    GPSTR  ug 2)32.1_
staticenG2.1_
staticenG2.1_
staticenG2.1_
stat.1_
staticenG2.1_
staticNt>(OIatderri8     G2.1tatiNX=n+4 L"""""mmmmd     rri8     Sf3)
#define ST_Sn        )Mtci P_pGe-2
statitci P_pGe-2    Gtativer-ena'   /* Sr+)Mte_Aa.
 * NeSteSta}S .Tppen",       NULL,   Can't_sav(tvice Wf    *s:    ath,         O_LOGR2ydfileName     *sIa el",          fOn",
   GET_ULL,)
#de  _S
   On",Environment()
JF   5ey        wputenv
 Skipame       return; se, BOOL isHelp)
Nt(e);
        }
        apxFrhRV    """mmmmd     r!rt(e);
        }
        apxFrperne               _SHtenv
 Skipanon-mod   r"tvasspath",            fOn",tenv
 T)
   atismmod   r"turn; se, BOOL isHelc APXCMDLINEOPT    [S   }
        apxFrh"JlSe        version* Sr+)MtSTpS. ->/* Sr+)Mtr
P_pGe-2atic H    )Mt""""mmmmd     rri8     Sf3)
#defi* NeSta}S .TppSubrvir, L"  --%s\n", _options[i].szName* NeSta}S .Tpp* Sr+)Mtr, L"  --%s\n", _options[i].szName* NeSta}S .Tpperne IDLWWLIwrappr.v_ucrt(e);
        }
        apxFree(e);
        whion* Sr+)MtSTpNum->/* Sr+)Mtr
P_pGe-2atic H    )Mt""""mmmmd     rri8     Sf3)
#defi* NeSta}S .TppSubrvir, L"  --%s\n", _options[i].szName* NeSta}S .Tpp* Sr+)Mtr, L"  --%s\n", _options[i].szName* NeSta}S .T.
 * NMicrosoftatic APXCMDLINEOPT    [S   }
        apxFrMSZl);
        whion* Sr+)MtSTpMzper->/* Sr+)Mtr
P_pGe-2atic H    )Mt""""mmmmd     rri8     Sf3)
#defi* NeSta}S .TppSubrvir, L"  --%s\n", _options[i].szName* NeSta}S .Tpp* Sr+)Mtr, L"  --%s\n", _options[i].szName* NeSta}S .Tpperne r, L"  --%s\n", _options[i].szName* NeSta}S .T.
 * NMicrosoftati

#define MOF, 0);ClosPool,
 /* Sr+)Mte;ioF, 0options[i].szValue)
 erSr
       }
        apxFr.
sta  *stderrv2y_e    e para P_pGe-2TTbhd'%
 TION      GET_OPET_OPTasspath         lestne paranMb-Pci %
 TION        		  *sIa el",    	          s */ prunsrv -- S%srtup
    if",i].szName);
        ++i;
    Environment()
JF   5ey       		CMDLINEOPT    [S   }
        apxFree(ee (*			rs */ prunsrv -- Serv:\n" e IDLWWLIaticemprtrloe* NeSta}S .T.
 * NMicr		} c APXCMDLINEOPT    [S   }
        apxFrMSZle (*			CMDLINEOPT    [Spperne Ie (*				rv2y_firs           				eLRtf2y_( =r* NeSta}S .Tpperne ;(*LL; 	osoftatirs */ prunsrv -- Serv:\\"WdliARTMODE        GET_OP(*LL; 	osoftati  }
4 L"""""mmmm	osoftati	CMDLfirs """""mmmm	osoftati		firs    el",        	osoftati	}ni_st8OCSDeF_	osoftati		fs */ prunsrv -- S#ydfileNam	osoftati	}ileNam	osoftati	// SkipamoePSTR  ug 2)3     leNameis  ",ilileNam	osoftati	  }
4p[0]"""""mmmm	osoftati		CMDLp[0]Aa.L'#'"""""mmmm	osoftati			fs */ prunsrv -- S'%calL a[0]"fileNam	osoftati		}ni_st8OCSDeF_	osoftati			fs */ prunsrv -- S%clL a[0]"fileNam	osoftati		}ileNam	osoftati		++pfileNam	osoftati	}ileNam	osoftati	// MoPPper-rri8     _
sta ",ilileNam	osoftati	++pfileNam	osoftati}ileNam	osoftatifs */ prunsrv -- S\" "Micr			gPidfileNamfic APXCMDLINEOPT    [SerSr
               _SHrs */ prunsrv -- Serv:\\"%s\" " IDLWWLIaticemprtrloe* NeSta}S .Tpperne IDLWWLIwrap  fOn",tenv/3      FALSE;e._
i o" edcrosoftati

#define MOF, 0options[i].szValue)
 Operareams(APX_STDWRAPrv2y_docmd hmodUcil_t() P_pGe-2TTbhd'%
 TION      GET_OPT_T(0)
#deil_t()#defineWrapperv#defineWrappebDsword" NULL)  el",        
       NULL)  cess maiDEM0) HANDL       
       }
 )  cess maiWIN32_OWN_PRO APX       , L"  sz4)
#[SIZ_HUGLEN]       , L"  szrtrl[SIZ_BUFLEN]   MOF, 0);ticenG2.1_
staticenG2.1_
sta hmodUc 2)3Foundati.2ydfileNameil_t()MDOPT_Filenail_t() 
staticSCULL,AGER_CREjU)vcess ma, el", ci P_pGe-2    Gtativer-ena'   /il_t()e_Aa.
 * NeSteSta}S .Tppen",       NU
stati"Un,ticNer-S)\name  il_t()MMan
#r2ydfileName     *sIa el",          fOn",
      Iatderri8 up TRUE           Denched by SC       apxFrperne 8OCSDeF_	tf(stderr, L"         _jp Service\n");
    fwprint		   NULL)  cess maie\n" HANDL       	} c APXCMDLtderr, L"         _jp Servic   { L");
    fwprint		   NULL)  cess maie\n" HANDL       		bDsword" NULL)  ice as cons	gPidfil  fOn",
      Iatderl_t()MT _o           De(      _s       apxFrperne 8&&ileName   tderr, L"       _,STR | APXCMDOPT_SR);
    fwp fOn",tenv/3 ve";
RONMas LocalS   APXer-rche SofLL, 0},

 flag fOn",tenv      *stut i = 0;
    whil  Denche gPoo       apxFrperne 8OCSDeF_________tut i      _jDLWWLIwrap  fOn",tenv  Detut&& tderr, L" su,_V(32calS   AP" /* ieFFn wpriniTGelBl:   }
 |  cess maiPXCMDOPT_SR_PRO APX       wrap ni_st8OCSDeF_r6:v_jnieSta}S .Tppen",       NU
stat, L"  --%s\n", _option            :D '-- }
 LL, 0},

'     tism ath, L"\ '--",        A LocalS   AP'O)Mtci P_pGe-2
st  *sIa el",        wrap  fOn",}ADAR,enseic     I  D-- hmodUcrid astderrv           De!  Gtiver-  *ING(or shutdowe_Aa.
 * NeStication\n"sz4)
#,STIZ_HUGLEN,[i].szName);
       )Mtci P_pGe- Display tsz4)
#,STIZ_HUGLEN,[    ")Mtci P_pGe- Display tsz4)
#,STIZ_HUGLEN,[i].szName);
        ++i;
    pGe- Display tsz4)
#,STIZ_HUGLEN,[  rtup"     else if (_lC- Se        ication\n"sz4)
#,STIZ_HUGLEN,[or shutdowe;AR,enseicRer
7M  ot_pGe-2
squot   *lpWrappO_NEtrQuot Inr
7Mn"sz4)
#e;AR,enseicAddRON-rl_t()M      wp R6   FALSEJvmOptionsDisplay tsz4)
#,STIZ_HUGLEN,[   "     elsication\n"szrtrloeSIZ_BUFLEN,[  //RS//"     elsicatioay tszrtrloeSIZ_BUFLEN,[y_
stati37 -- Service R6        O_NEtrQuot Inr
7Mn"sz  GET_OPT_V(sDisplay tsz4)
#,STIZ_HUGLEN,[sz  GET_OPT_V(or shutdown  *s    "Etrdupy_
staticsz4)
#e;AR,enseicEnsPXCM      FALSEJgbDResav(d     Sof         *lpWrapp)

static|       apxFrperne;ion */
  .1_
sMOF, 0
 erSr
    paranMandsFALSE;
   On",ion  s -- Ser;APXCMDLINEF, 0eSta}S .Tppen",       NUINFOta hmodUc 2)3Foundateeeee      eeeeeeeri8     G2.1tatiNX=n+4 L"""""mmmmd     rri8      _jni_stare;ioF, 0ovt iPT_",      hmodUc /il_t()r, L"  --%s\n", _options[i].si8     G2.1tatiNX=n+4 L"""""mmmmd     rri8     Sf3)
     _jni_star,F, 0
 --        APX  *lpWrapper->fpStdOut    Sf3)
   
stati""""mmmmd     rri8     Sf3)
         _ja

#def
 --           A *lpWrapper->fpStdOut    Sf3)
   }
""""mmmmd     rri8     Sf3)
   NULLe;AR,enseice paranMapxExssword"              L  Deovt&ebDsword" NULL 8OCSDeF_	tf(s!PT_",     Se;
      /il_t()r, L"  --%s\n", _options[i].s  Sf3)
   }
""""mmmmd     rri8     Sf3)
  Sf3)
   NULL""""mmmmd     rri8     Sf3)
  Sf3)
bDsword" NULL""""mmmmd     rri8     Sf3)
  Sf3)
cess maiNO_ L"NGEile (*LL;    /* SheSta}S .Tppen",       NULL,   Fa}
";
  paranMa3FoundateleNassword"      up"IDLWWLIwrap  fOn",  fOn",
 ache Sof--        APX        L  Deovle (*LL;    /      *stdt i = 0;
    whil      *stut i = 0;
    whil      *stpt i = 0;
    whil         esultpache Sofy_
s  Denchrker       *       apxFrperne 8OCSDeF_________tdt i   rker       ;(*LL;    /* SheSta}S .Tppen",       NU *stderri8aOerSFoundated       APX eeeeeeeeeeeeeeeeeeee(e Apache Sof   rker       rints version. */
static vnche gPoo       apxFrperne 8OCSDeF_________tut i      _jDLWWLIwrap* SheSta}S .Tppen",       NU *stderri8aOerSFoundateu  A eeeeeeeeeeeeeeeeeeee(e Apache Sof      _jrints version. */
static vnchetic APX_S       apxFrperne 8OCSDeF_________tvbuf(stetic APX_DLWWLIwrap* SheSta}S .Tppen",       NU *stderri8aOerSFoundatep",      eeeeeeeeeeeeeeeeeeee(e Apache Sof    tic APX_->fpS[SerSr
    }
4 L"E",     Se; APX  /il_t()r
    if    ifsdifsu,_sSTR gPidfileN   esultt iPT_",cu.TpyGran
    AchePSTo   A(LE gPidfilifsu append mode
     esultle (*LL;    /* SheSta}S .Tppen",       NULL,   Fa}
";
gran
SFoundateu  A eeee w.Tpp pSTR ssLSE;
    * Alleeee ducNer-e 9C3leed'eeeeeeeeeeeeeee(e Apache Sofsu,_LE gPidfilif   esultlDLWWLIwrap  fOn",  fOn",);ClosPool,
 /il_t()e;     L  Deovle (*LL;    /sav(e paranMb-Pci %
 TION   ;    }
4 L"Ea}S .Tppen",       NUINFOtaSoundateeeee WSTR p,rv2yeeeeeeeeeeeeee(e Apachey_
stati37 -- Service R6        e if (_lC- Se        eSta}S .Tppen",       NU
stati"Fa}
";ihmodUc 2)3Foundateeeee2yeeeeeeeeeeeeee(e Apachey_
stati37 -- Service R6    MOF, 0optionsrv#de
\n");r  LPrv2y_docmdtbase.il_t() P_pGe-2TTbhd'%
 TION      GET_OPT_T(0)
#deil_t()#defineWrapperv                 L"Ea}S .Tppen",       NUINFOtatbase 2)3Foundati.2ydfileNameil_t()MDOPT_Filenail_t() 
staticSCULL,AGER_CONNECT, el", ci P_pGe-2    Gtativer-ena'   /il_t()e_Aa.
 * NeSteSta}S .Tppen",       NU
stati"Un,ticNer-S)\name  il_t()MMan
#r2ydfileName     *sIa el",          fOn",
 tbase.dFoundate,
  etProatderl_t()M-2 RONn 2)3       L  DeL"E",     O)\n"/il_t()r
i8     G2.1tatiNX=n+4 L"" cess maieLL_A  APXC_Aa.
 * NeSt, L"  szWndMan
#rUSER [SIZ_RESLEN]           (0)
#deWndMan
#rt i = 0;
    whilication\n"szWndMan
#rUSER ,STIZ_RESLENwprintf(stderr, L"  print   [ServiceNasDisplay tszWndMan
#rUSER ,STIZ_RESLENwpL"   /* ydfileName   eicelosPoatdemoniNameOPT_STE | AP-2 RONn 2)3       L   L  De(eWndMan
#rt iFind       tszWndMan
#rUSER ,S     )            {
    BOOL pS   STARTIM(eWndMan
#r, WM   OSr,F0isplays comamnd line paramovt iPT_",     tbase. /il_t()e;     L}     L  Deovle (*LL;    /
 tbase.ddUcrrl_t()M            *s  erminate the arrtbase.mtderrv2y_cenG2.1_
sta
i8     G2.1tatiNX=n+4 L"" PSTR  ug 2)32 ice  ;    }
4 L"Ea}S .Tppen",       NU *stderriundateeeee t = Lov2yeeeeeeeeeeeeee(e Apachey_
stati37 -- Service R6        e if (_lC- Aa.
 * NeSteSt       e 9C3\el", V(33)
#d,i"Un,ticNer-dbase.dFoundateeeeeeeeeeeeeeeeeeeee(e Apache Sofy_
stati37 -- Service R6          fOn",);ClosPool,
 /il_t()e;     LL"Ea}S .Tppen",       NUINFOtatbasea3Foundatelinishrv2ydfileNamoptionsrv#de
\n");r  LPrv2y_docmd "_wil_t() P_pGe-2TTbhd'%
 TION      GET_OPT_T(0)
#deil_t()#defineWrapperv                 L"Ea}S .Tppen",       NUINFOta "_wp 2)3Foundateeeee2.eeeeeeeeeeeeeeee(e Apy_
stati37 -- Service R6        eil_t()MDOPT_Filenail_t() 
staticGENERICieLL, el", ci P_pGe-2    Gtativer-ena'   /il_t()e_Aa.
 * NeSteSta}S .Tppen",       NU
stati"Un,ticNer-S)\name  il_t()MMan
#r2ydfileName     *sIa el",          fpWrapp)      NULL,           APXCMDOPT_M
 Openoatderl_t()M       L  DeL"E",     O)\n"/il_t()r
i8     G2.1tatiNX=n+4 L""eeeeeeeeeeeee(e Apache SoGENERICier- theGENERICiEXECU"Eile (*LL;    /ovt iPT_",     e ptroc /il_t()r, L"  --%s\n", _options[i].sssssscess maiCONTROL;    r, L"  --%s\n", _options[i].ssssss0r, L"  --%s\n", _options[i].ssssss    i, L"  --%s\n", _options[i].szName     append mode
  !ovle (*LL;    /////
 
  ileName  t ST_INe
 andefine SO_LOGLEVEL (wput ST_INeeeee=ULL;    /* ShutDLWWLIwrap* Sh
  t ST_IN              _SHtenvET_OP;           _SHtenv  setPTassp i <ut ST_INp i, 0&}
    }
             ovt iPT_",     e     "_w /il_t()e;     LLLLLLLLLLLLLLLLLL"Ea}S .Tppen",       NU *stderPT_",     e       *sIa:\n"eeerrvs     *s        wrap* Sh
  rvstdout, NULL, _IONBF, 00000ename) {
              gPidfileName   gPidfileNamn. */
static vrvstdout, NULL, _L"Ea}S .Tppen",       NUINFOtaSoundateeeee etPrpov2yeeeeeeeeeeeeee(e Apacheeeeey_
stati37 -- Service R6         :D lC- Se        version  s -- Service R6   =
stati"Fa}
";er-rrProFoundateeeeeeeeeeeeeeeeeeeee(e Apache Sofy_
stati37 -- Service R6          fOn",lC- Se        eSt       e 9C3\el", V(33)
#d,i"Un,ticNer-S)\naFoundateeeeeeeeeeeeeeeeeeeee(e Apache Sofy_
stati37 -- Service R6        );ClosPool,
 /il_t()e;     LL"Ea}S .Tppen",       NUINFOtaSrProFoundatelinishrv2ydfileNamoptionsrv#de
\n");r  LPrv2y_docmd "artil_t() P_pGe-2TTbhd'%
 TION      GET_OPT_T(0)
#deil_t()#defineWrapperv                 L"Ea}S .Tppen",       NUINFOta "art 2)3Foundateeeee2.eeeeeeeeeeeeeeee(e Apy_
stati37 -- Service R6        eil_t()MDOPT_Filenail_t() 
staticGENERICieLL, el", ci P_pGe-2    Gtativer-ena'   /il_t()e_Aa.
 * NeSteSta}S .Tppen",       NU
stati"Un,ticNer-S)\name  il_t()MMan
#r2ydfileName     *sIa el",          fpWrapp)      NULL,           APXCMDOPT_M
 Openoatderl_t()M       L  DeL"E",     O)\n"/il_t()r
i8     G2.1tatiNX=n+4 L""eeeeeeeeeeeee(e Apache SoGENERICier- theGENERICiEXECU"Eile (*LL;    /ovt iPT_",     e ptroc /il_t()r, L"  --%s\n", __________________cess maiCONTROL;CONTINerr, L"  --%s\n", _options[i].szName0r, L"  --%s\n", _options[i].ssssss    i, L"  --%s\n", _options[i].szName     append mode
  rvstdout, NULL, _L"Ea}S .Tppen",       NUINFOtaS"artd"  ]  eeeeeeeeeeeeeeeeeeeeeeee(e Apache Sofy_
stati37 -- Service R6         :D lC- Se        version  s -- Service R6   =
stati"Fa}
";er-rr     ]  eeeeeeeeeeeeeeeeeeeeeeee(e Apache Sofy_
stati37 -- Service R6            fOn",lC- Se        eSt       e 9C3\el", V(33)
#d,i"Un,ticNer-S)\naFoundateeeeeeeeeeeeeeeeeeeee(e Apache Sofy_
stati37 -- Service R6        );ClosPool,
 /il_t()e;     LL"Ea}S .Tppen",       NUINFOtaFinishrv-rr    2)3Foundateeeee,   *sIa 2)3n"eeeri8     G2.1tatiNX=n+4 L"" rvs     *soptionsrv#de
\n");r  LPrv2y_docmdT)
  il_t() P_pGe-2TTbhd'%
 TION      GET_OPT_T(0)
#deil_t()#defineWrapperv   ice as      LL"Ea}S .Tppen",       NUINFOtaT)
  2)3Foundati.2ydfilileNameil_t()MDOPT_Filenail_t() 
staticSCULL,AGER_CREjU)vcess ma, el", ci P_pGe-2    Gtativer-ena'   /il_t()e_Aa.
 * NeSteSta}S .Tppen",       NU
stati"Un,ticNer-S)\name  il_t()MMan
#r2ydfileName     *sIa el",          fOn",)      NULL, 0CMDOPT_M
 Openoatderl_t()M       L  De!L"E",     O)\n"/il_t()r
i8     G2.1tatiNX=n+4 L"" cess maieLL_A  APXC_Aa.
 * NeSteicelosPoatdeexis  2)3man
#rtO_LOGRrNE lpCmdline, Ith,
     reS)\n
";ihmide;ihmodUcNE lpCmdline, BOOL isHel);ClosPool,
 /il_t()e;     LNeSteicIn ce:\n"undatedoesn't_exis      statimodUcritNE lpCmdline, IimodUcr,
  fa}APXCMDOP_e);
  minimum        :D         vNE lpCmdline, BOOL isHel  *sIa docmd hmodUcil_t() %
 TION   ;    }e if (_lC- Aa.
 * NeSt
       NULL)  cess maiNO_ L"NGE;
    whil         esultpac    whilWrappebDsword" NULL)  el",        whil         }
 )  cess maiNO_ L"NGE;
    whil      *stut i = 0;
    whil      *stpt i = 0;
    whilic vnche gPoo       apxFrperne 8OCSDeF_________tut i      _jDLWWLIwrap* SheSta}S .Tppen",       NU *stderri8aOerSFoundateu  A eeeeeeeeeeeeeeeeeeee(e Apache Sof      _jrints version. */
static vnchetic APX_S       apxFrperne 8OCSDeF_________tvbuf(stetic APX_DLWWLIwrap* SheSta}S .Tppen",       NU *stderri8aOerSFoundatep",      eeeeeeeeeeeeeeeeeeee(e Apache Sof    tic APX_->fpS[SerSr
    }
4 rv   eovt&& L"E",     Se; APX  /il_t()r, L"  --%s\n", _options[i].szNameeeeeeeee33)
################Loadev A 
    ifatde4)
#le is*lpWrapper->fpStdOut    Sf3)
(e Apache Sof     _jni_star,pWrapper->fpStdOut    Sf3)
(e Apache Sof    ker       ,pWrapper->fpStdOut    Sf3)
(e Apache Sofsu,pWrapper->fpStdOut    Sf3)
(e Apache SofspMe     *s       esultt iPT_",cu.TpyGran
    AchePSTo   A(LE gPidfilifsu append mode
     esultle (*LL;    /* SheSta}S .Tppen",       NULL,   Fa}
";
gran
SFoundateu  A eeee w.Tpp pSTR ssLSE;
    * Alleeee ducNer-e 9C3leed'eeeeeeeeeeeeeee(e Apache Sofsu,_LE gPidfilif   esultlDLWWLIwrap  fOn",,,,,
 T)
    Sof--Sri8 up TRUE         mode
  nched by SC       apxFrperne 8OCSDeF_    mode
  !tderr, L"         _jp Servic   { L")0&}
    }
            NULL)  cess maiDEM0) HANDL                   bDsword" NULL)  ice as consWLIwrap  fOn",,,,,,,,,c APXCMDL!tderr, L"         _jp Service\n")stdout, NULL, _IONB   NULL)  cess maie\n" HANDL       ,,,,,,,,c APXCMDL!tderr, L"         _jp ServicM0)UAL)stdout, NULL, _IONB   NULL)  cess maiDEM0) HANDL           n. */
static vnch   _s       apxFrperne 8OCSDeF_    mode
  !tderr, L"       _,STR | APXCMDOPT_SR)stdout, NULL, _IONB   }
   cess maiWIN32_OWN_PRO APXthecess maiPXCMDOPT_SR_PRO APX       wrap     }
4 rv   eovt&& L"E",     Se;
      /il_t()r, L"  --%s\n", _options[i].s  Sf3)
, _IONB   }
r, L"  --%s\n", _options[i].s  Sf3)
, _IONB   NULL""""mmmmd     rri8     Sf3)
  Sf3)







bDsword" NULL""""mmmmd     rri8     Sf3)
  Sf3)







cess maiNO_ L"NGEilpache Sofy_
sL"Ea}S .Tppen",       NUINFOtaT)
 d"  ]  eeeeeeeeeeeeeeeeeeeeeeee(e Apachey_
stati37 -- Service R6              rv   eovt&& sav(e paranMb-Pci %
 TION             fOn",);ClosPool,
 /il_t()e;     L
  rvstdout, NULL"Ea}S .Tppen",       NUINFOtaFinishrv-u)
  2)3Foundat eeeeeeeri8     G2.1tatiNX=n+4 L"e;     LlC- Se        eSta}S .Tppen",       NUINFOtaFa}
";u)
  2)3Foundat eeeeeee"""mmmmd     rri8     Sf3)
  Sf3)



i8     G2.1tatiNX=n+4 L"e;     Loptionsrv#de
\n"eicRerortoatderl_t()M  if (>(OIatdeSCM,atic LP 2)3Foundat        c_exi
  drr");");B  c"aPperSpen(");Bunsrv --docs.microsoft.com/en-us/w     s/w  32/api/w  svc/ns-w  svc-rl_t()   if (");");Bcess maiCONTINer_    ING  0x00000005U)v Wrl_t()M    if (rid aCMDLtup)_PPBcess maiPA  __    ING     0x00000006U)v Wrl_t()M* Shutid aCMDLtup)_PPBcess maiPA  _D
  Sf3)



0x00000007U)v Wrl_t()Mid apgWorp)_PPBcess maiRUNNING     )



0x00000004U)v Wrl_t()Mid RONn 2)p)_PPBcess maiHANDL_    ING     0x00000002U)v Wrl_t()Mid rr    2)p)_PPBcess maiHAOP_    ING      0x00000003U)v Wrl_t()Mid rr_wp 2)p)_PPBcess maiHAOPP_D
  Sf3)


0x00000001U)v Wrl_t()Mid  ot_RONn 2)p)_PP
            lstrrort",     S if (E(        Lev or n Seconds (defaults to 60)\n");
         c"aPperSpen(r n Seconds (defaults to 60)\n");
         W  32f (lC drr n Seconds (defaults to 60)\n");
         WaitHinL""""mmmmd     rri8     Sf3)
  Sf3)
       ,     S      cf (lC dr    GET_O               c    PoipWrapci P_pGrv2y_f esultt iice as      eSta}S .Tppe33)
#  Lev orstderr _eSta}S_r _eTbhdS_r _efuncS_r"""mmmmd "trrort",     S if (E:   c"aPperSpen(t iL"  is),   W  32f (lC drt iL",   WaitHinLt iL" m
 isrm lo ,    ,     S      cf (lC drt iL"eee"""mmmmd   c"aPperSpen(r L"E",     .TpS.en( APX(  c"aPperSpen(),   W  32f (lC dr,   WaitHinL,    ,     S      cf (lC dr         CMDLIrl_t() TRUE     rl_t()   if (_O_LOGR 8OCSDeF_   
    c"aPperSpen(t =Bcess maiRUNNINGstdout, NULL, _ rl_t()   if (.  c ptrocsAchep d"   cess maieCCExFrh"OPthecess maieCCExFrhHUTDOWN        :D lC- Se        vers rl_t()   if (.  c ptrocsAchep d"   0             rl_t()   if (.  c"aPperSpen(t     c"aPperSpen(;          rl_t()   if (.  W  32f (lC drt i  W  32f (lC dr;          rl_t()   if (.  WaitHinLtttttt=   WaitHinL;          rl_t()   if (.   ,     S      cf (lC drt i   ,     S      cf (lC dr              De(  c"aPperSpen(t =Bcess maiRUNNINGs   """mmmmd     (  c"aPperSpen(t =Bcess maiHAOPP_D)stdout, NULL,  rl_t()   if (.  c    PoipWrape     *s   lC- Se        ver rl_t()   if (.  c    PoipWrap  c    PoipWG2.1_
stat.1f esultt iSTpS,     S if (( rl_t()   if (_O_LOGR, & rl_t()   if (lDLWWLIwra
  !f esultle (*LL;    /* S
   GET_Deal L"\ e 9C3l*lpWrapper->fpSion  s -- Service R6   =
stati"Fa}
";er-reterl_t()M  if (2ydfileName    fOn"  fOn"optionsf esultpac
\n"eicRerortoatderl_t()M  if (>(OIatdeSCMp)_PP
            lstrrort",     S if ((        c"aPperSpen(r n Seconds (defaults to 60)\n");
        W  32f (lC drr n Seconds (defaults to 60)\n");
        WaitHinL    GET_OP//_exi
  dr 0     Loptionsrrrort",     S if (E(rvice R*stder *std,   c"aPperSpen(r   W  32f (lC dr,   WaitHinL, 0CMDO
\n"eicRerortocess maiHAOPP_D
(OIatdeSCMp)_PP
            lstrrort",     S if (StPrpov(      e (lC dr    GET_OLoptionsrrrort",     S if (E(rvice R*stder *std, cess maiHAOPP_D, e (lC dr ?
 * Necess maiHPECIFICiEstati: NO_Estat
#d,ie (lC dr    
\n"   lschild_callback(T_T(0)
#deObjecL, UPXC uMsgr n Seconds (defaults tWatic  w{
  zStdEic  l{
      GET_OP/
   GET_Mak
        gPid %d\n",buffertci ic L*
(OIpre
  d %);
  LL, 0mix 2)3whenoatdr         e);
  se    t 0);
 DCptiachd %);
NE lpCmd       L  DeuMsgt =BWM  APXCAa.
 * NeSta}
 hOCNMO    (w{
      
 * NeStaMDLt{
      (defaults tfputc(ch,d %d\n"         :D lC- Se        versfputc(ch,d %d_IN          fOn",options[i].szVOn",UNREFERENCED2atic ETER(eObjecL    
\n"       a}
onf (l "_w 
            CMDLIrl_t() TRUE"""""mmmmd       _pGelp)
     SbDC_pGelBl: SrProexi
hook c p,rv2.2ydfileName     rort",     S if (StPrpov(      else if (_options0   
\n"       a}
onf (l "    
            CMDLIrl_t() TRUE"""""mmmmd       _pGelp)
     SbDC_pGelBl: SrULL)exi
hook c p,rv2.2ydfileName       _pGelp)
     SbDC_pGelBl: JVM_exi
  dr:3n"eeer}R
  Vmf (lC dr()e;     LNeSteicR or moreatderl_t()Mas etPrpov e
  L"\ aanon-zero_exi
  drSe        vth,
   ot_c Shutrrm very a/* Shu
(OIbe;ihiti
 d",d xA("n't_  rort at dUcNE lpCmdline, "AWrl_t()Mid pandid\nov fa}
";whenoi
PSTR  uge; L"\    e or moreaE lpCmdline,   if (>ofocess maiHAOPP_D
(OIatderl_t()M    rocler"E lpCmdline, unsr --msdn.microsoft.com/en-us/lIBRARY-ms685939(VS.85).aspxE lpCmdline,       mode
  }R
  Vmf (lC dr()/* ieFFn wpriniTGelBl:  rort",     S if (StPrpov(      els else if (_e if (_options0   
\n"uO)Mt    
";whenoatderl_t()Mrrmeiv(lsrrProe
  .
sta  *stder      WINAPIerl_t() "_w LPVOID lpP      :D    GET_OPT_T(0)
#deWork#rt i = 0;
           rv   e     *sWrappe wait_to_die)  el",        
    ut ST_INeeeee=ULL;    /* Shute, 1000       
    u  ctrl }
 )  (     )((BYTE *)lpP      :D - (BYTE *)0          L"Ea}S .Tppen",       NUINFOta "_wp 2)3Foundati.2ydfilileNam-2    Gtativer-ena'   gWork#re_Aa.
 * NeSteSta}S .Tppen",       NUINFOtaWork#rtid  ot_definrv2ydfileName     *sIa [i].sNeSteicdLibraryExA("ucrtbf (_e if (_
  t ST_INDeFFx7FFFFFFF    (default ST_IND= INFINIT.sNeStteicIfame  t ST_INewas '-1' wait DCpewerd       L  De_jni_shu%d_wr- thjP7M       De!  Gtiver-  *ING(or HANDLdfil 8&&   Gtiver-  *ING(or HAOPPfil le (*LL;    /////
 Ifame  Workrary* Allid r      r"tnhangr
        }
dirrmtoNt>oApachogPaline, but  tismPXCMDO-rr    * Allwasn't_s      r"tal);dy.>oApachogPaline,lpWrapper->fpStStic"aPperDirrmtoNtW(or HAOPPfil        wrap     }
4 eWork#rt iPT_FilenaREh">szStdEr*jni_jvm* Al,_LE JAVAHOME    
 * NeStaMDL  Gtativer-ena'   /Work#re_Aa.
 * NeStNeSteSta}S .Tppen",       NU
stati"Fa}
";ceName   REh"Jeeeeeeer*jni_jvm* Al)Mtci P_pGe-2
st  *sIa 1       wrap     }
4 gSargs.hREh"JJJJJJJJJJJJ= eWork#r;    }
4 gSargs.szUSER le isJJJJJ= *jni_cSER * Al;    }
4 gSargs.lp
     JJJJJJJJ= *jni_jvmoprin/  }
  3
4 gSargs.lp
     9JJJJJJJ= *jni_jvmoprin/ 9 }
  3
4 gSargs.dwM JJJJJJJJJJJJJ= LE JVMMS }
  3
4 gSargs.dwMxJJJJJJJJJJJJJ= LE JVMMX }
  3
4 gSargs.dwS JJJJJJJJJJJJJ= LE JVMSS }
  3
4 gSargs.bJniVf */ pJJJJJ= LE JNIVFP*INTF;    }
4 gSargs.szUSER  APX  JJJJ= *jni_scSER ;    }
4 gSargs.szMe"\ d APX  JJJ= *jni_sme"\ d }
  3
4 gSargs.lpArgulenoES  JJJ= *jni_s     ;    }
4 gSargs.sz/issues.ap  int i = 0;
    whilgSargs.sz/is
{
    int i = 0;
    whilgSargs.szLIBRARYle isJJJ= LE LIBPfil;     LNeSteicR derr#rtonexi
hookE lpCmdline,       mode_onexi(onf (l "_wdfileName   eice
#defshu%d_wroe
  e,       modegShu%d_wrE
  e=ce
#deE
  e33)
#tderr el", V(33) append mode
  !eStREh" "    &gSargse_Aa.
 * NeStNeSteSta}S .Tppen",       NU
stati"Fa}
";rr    2)3REh".O)Mtci P_pGe-2
st v   3       wrap     }
4 i_st8OCSDeF_r6:v_jniCMDLtderr, A(*jni_scSER , "jEh"/lang/S   AP" /* ieFFn wpriniTGelBl:2
st rrort",     S if ((cess maiHAOP_    ING, NO_Estat
#20e, 1000s     *s        wrap    _pGelp)
     SbDC_pGelBl: Force   REh"JJNI S   AP.exi() work#rtExAlinish2.2ydfileName   lBl:2
st rtions0   e   lBl:2
st  fOn",,,,,,,,,c APXn wpriniTGelBl:2
st    _pGelp)
     SbDC_pGelBl: Waite   DCptREh"JJNI rrProwork#rtExAlinish DCpt%s:%s2.eee *jni_scSER , *jni_sme"\ de     *s            CMDL!t ST_IN  n Seconds (defaults teStREh"Wait /Work#r, INFINIT., el", ci P_pGeOn",,,,,,,,,c AP n Seconds (defaults teStREh"Wait /Work#r, t ST_IN, el", ci P_pGeOn",,,,,,,,,    _pGelp)
     SbDC_pGelBl: JEh"JJNI rrProwork#rtlinishrv2ydfileNamlBl:2
st  fOn",,,,,  fOn",,,,,wait_to_die)  [i].szVOn",e if (_lC- AaMDL  Gtiver-  *ING(or HAOPMODEile M
 OtismPn ce:\nwe hav(ta rrProTRUE         mode
    nArg ;    }
4 PREh"Jv*pArg ;  hjP7M       De!  Gtiver-  *ING(or HAOPIMAGEile (*LL;    /* SheSta}S .Tppen",       NU
stati"M ssL2)3Foundat 4)
#
  2ydfileNamlBl:2
st  De!Irl_t() TRUE" P_pGeOn",,,,,,,,,          e 9C3\el", V(33)
#d,i"Soundateeeee id m ssL2)3atde4)
#
  2yr n Seconds (defaults to 60)\n");
Irl_t()   int?
Irl_t()   int: L"unkn_wrO)Mtci P_pGe-2
st  *sIa 1       wrap     }
4 eicR dirrmt asthePS         modeeWork#rt iPT_Filena- thePSy_
stati n Seconds (defaults to 60)\n");




0r, L"  --%s\n", _options[i].ssssssssssschild_callbackr, L"  --%s\n", _options[i].sssssssssssor   _jr, L"  --%s\n", _options[i].sssssssssssor tic APX_r, L"  --%s\n", _options[i].sssssssssssel", ci P_pGeOn",aMDL  Gtativer-ena'   /Work#re_Aa.
 * NeStNeSteSta}S .Tppen",       NU
stati"Fa}
";ceName   asthePS.O)Mtci P_pGe-2
st  *sIa 1       wrap     }
4 eicIfame  rl_t()M*sthePS compaseas beDCpeCMDO-rrPro*sthePS doesCMDOE lpCmdline, cleanup
  dr belowr,
  freO-rrruc*sI          v   MDO-rrPro*sthePSSe        vth,hichr,
 ,atiddUcr*stbability, trig
#rta;ceash2 
  ileName  rrPrSe        vth*sthePS 
  mpasea beDCpeCcleane   upNE lpCmdline, BOOL isHelgShu%d_wrE
  e=ce
#deE
  e33)
#tderr el", V(33) append mode
  !eSt- thePSSti        ++W /Work#r, or HAOPIMAGEile (*LL;    /* SheSta}S .Tppen",       NU
stati"Fa}
";ri8aOerS*sthePS e       ++ eeeeeeeeeeeeeeeeeeee(e Apache Sof    AOPIMAGEiMtci P_pGe-2
st v   2Mtci P_pGe-2
stgo
 leanup       wrap     }
4 eicAssemticNe         wp R6  ,       mode
  _jEh"_shu%d_wr- thjP7M         nArg t iPT_JEh"Cmd hiti
liz 
staticSO   /* dfilif    AOP  /* """"mmmmd     rri8     Sf3)
  Sf3)







cO",eSu
#IONS, LE JVMMS, LE JVMMX""""mmmmd     rri8     Sf3)
  Sf3)







cO",eSSSif    AOPatic H, &pArg         wrap     }
4 c APXn wpriniTGelBl:nArg t iPT_    ealToA
#dW 
staticSO  AOPatic H, &pArg         wrap       }
4 eicPassCMDO argv 
 hild asthePS         mode
  !eSt- thePSStiC     wArg W /Work#r, or HAOPIMAGE""""mmmmd     rri8     Sf3)
  Sf3)





nArg , pArg  FFn wpriniTGelBl: v   3       wrapppppeSta}S .Tppen",       NU
stati"Fa}
";ri8aOerS*sthePS argulenoES(argc=%d)eeeeeeeeeeeeeeee(e Apache SofnArg         wrapppppgo
 leanup       wrap     }
4 eicache Sofworkrary* All        mode
  !eSt- thePSStiWorkrarle iW /Work#r, or HAOPPfil le (*LL;    ///// v   4       wrapppppeSta}S .Tppen",       NU
stati"Fa}
";ri8aOerS*sthePS workrary* All
eeeeeeeeeeeeeeeeeeee(e Apache Sof    AOPPfil        wrapppppgo
 leanup       wrap     }
4 eicFindUcy e     cNe    hild asthePSE lpCmdline,       mode
  !eSt- thePSMt    
 /Work#re_Aa.
 * NeStNeSt v   8           
     ni3(i  ",ilen        
stati"Fa}
";e     e   asthePS.O)Mtci P_pGe-2
stgo
 leanup       wrap ni_st8OCSDeF_r6:v_jnieSta}S .Tppen",       NUGelBl: Waite   DCptrrProwork#rtExAlinish2.2ydfileName   lBl:CMDL!t ST_IN  n Seconds (defauleStool,
Wait /Work#r, INFINIT., el", ci P_pGeOn",,,,,c AP n Seconds (defauleStool,
Wait /Work#r, t ST_IN, el", ci P_pGeOn",,,,,    _pGelp)
     SbDC_pGelBl: SrProwork#rtlinishrv2ydfileNamlBl:  fOn",,,,,wait_to_die)  [i].szVOn",e i leanup:zVOn",eicelosPoJEh"JJNI O_LOGR CptrrProwork#r fOn",,icIfameid isCMDO sL2)GR JVM_timodcNt>ith,
  unestn fOn",,icMDO JVM_dR gPooNE lpCmd U)v Wwork#rt,
     closPd onaFoundateexiNE lpCmd       L  De!  Gtativer-ena'   /Work#re_ fOn",,,,,);ClosPool,
 /Work#re;     L
  gSigndUE
  _Aa.
 * NeStgSigndUVath,  el",        whilSti 
  egSigndUE
  _       whilWaitForSL2)GRObjecLegSigndUTh);d, 1000s     *s    ClosPool,
 gSigndUE
  _       whilClosPool,
 gSigndUTh);d_       whilgSigndUE
  t i = 0;
    e if (_
  wait_to_die)&& !t ST_IN  n Secondst ST_IND= 300e, 1000;n",eicUsPoatde5 min  cNdefaulttshu%d_wro     if (_
    ctrl }
  =Bcess maiCONTROL; HUTDOWN  n Secondst ST_IND= MIN(t ST_IN, }R
  MaE",     T ST_IN 
stat)e;     L rrort",     S if ((cess maiHAOP_    ING, NO_Estat
#t ST_IN filileNam-2  t ST_IN             Sta}/* S ft , fn(;          ULARGaiPXCMGER  , (;          
    uofnm ;    }
4 
 
  i
g

   iatnhanNt>(OIdie)nif rdUcy,oatdn kiUcritNrminate the arr
      staf (!chemas-GelBl: Waite   DCptwork#rtExAdie)nif rdUcy2.2ydfileName   .TpS   APT STAs
  T ST(&ft dfileName    vt iPT_ool,
Wait gWork#r, t ST_IN, ice  ;    }
4 .TpS   APT STAs
  T ST(&fte;     LNeSts.Low{
tJJ= ft .dwLowD#deT ST;     LNeSts.HighPULL)  ft .dwHighD#deT ST;     LNeSte.Low{
tJJ= fte.dwLowD#deT ST;     LNeSte.HighPULL)  fte.dwHighD#deT ST;     LNeStnm )  (     )((e.QuadPULL)-ts.QuadPULL) / 10000 append mode
   vt = WAIT_OBJECT_eFFn wpriniTGelBl: v   e     *ste the arr
      staf (!chemas-GelBl: Work#rtlinishrvgracefulismPn L" m
 isrm lo eee nm         wrap     }
4 c AP    *ste the arr
      staf (!chemas-GelBl: Work#rtwas kiUc(d    L" m
 isrm lo eee nm         e if (_lC- Aa.
 * NeSteSta}S .Tppen",       NU *stderriMDLtu WM   OSrtExAwork#r2ydfileName      ool,
S   STARTIM(gWork#r, WM   OSr,F0isplays com}        L"Ea}S .Tppen",       NUINFOta l_t()M  Proat);d  mpaseav2ydfileNam
  gShu%d_wrE
  FFn wpriniTGeSti 
  egShu%d_wrE
  F    else if (_optionsrv#de
\n"eicMt    
";whenoatderl_t()Mrrmeiv(lsrrULL)e
  .
sta  *stder      rl_t() "        GET_OP       rv   e     *s       nArg ;    }PREh"Jv*pArg ;    }Sta}/* S ft          L"Ea}S .Tppen",       NUINFOta "    2)3Foundati.2ydfilileNam-2  !  Gtativer-ena'   gWork#re_Aa.
 * NeSteSta}S .Tppen",       NUINFOtaWork#rtid  ot_definrv2ydfileName     *sIa [i].sNeSteicdLibraryExA("ucrtbf (_e if (_
    Gtiver-  *ING(or PIDSta}e_Aa.
 * NeStgPid);
N int ieSta}S
   
staticSO gPidfilifor PIDSta}V(33)
#el", V(0 append mode
  .Tp    Attrib  
Sy_
sid);
N in)     tativer-Sta}SAT *IBUTESle (*LL;    /////
 sid0);
 exis   *lpWrapper->fpSt-2  !tbasea    y_
sid);
N in)              _SHtenv
 tbasea3fa}
". Eiatdr
  achePS CptS)\n
";*lpWrapper->fpStdOut   ni3(i  ",ilen        
stati"sid0);
 eeee exis  2yr n Seconds (defaults to 60)\n"
sid);
N in)fileName   lBl:2
st rtions1fileName   lBl:  fOn",,,,,  fOn",  fOn",.TpS   APT STAs
  T ST(&ft dfileNam  De_jni_sri8 up- thjP7M       De  GEMPTY-  *ING(or HANDLdfil   n Seconds (deor HANDLdfilt ig "   P Al;    }
4 aMDL  Gtiver-  *ING(or HANDLdfil  e (*LL;    /////
 Ifame  Workrary* Allid r      r"tnhangr
        }
dirrmtoNte,lpWrapper->fpStStic"aPperDirrmtoNtW(or HANDLdfil        wrap     }
4 aMDL  Gtiver-  *ING(or LIBPfil  e (*LL;    /////
 AddLIBRARYle is(OIatdedfilt*lpWrapper->fpSionAddTole iW 
staticSO gIBPfil        wrap     }
4 eicaom   FALSE;        addiALSEal environm
  d   *s  er(OIbe;ih r
7ME lpCmdline, beDCpeCJEh"Jid rr   edcrosoftatie,       mode
    Gtiver-  *ING(or ,eSu
#IONS  e (*LL;    /	   InasthEnvironm
  
      or ,eSu
#IONS        wrap     }
4 eice
#defMDO JVM_global ork#rt, BOOL isHelgWork#rt iPT_FilenaREh">szStdEr*jni_jvm* Al,_LE JAVAHOME    
 * NeStaMDL  Gtativer-ena'   gWork#re_Aa.
 * NeSt>fpSiona}S .Tppen",       NU
stati"Fa}
";ceName   REh"Jeeeeeeer*jni_jvm* Al)Mtci P_pGe-2
st  *sIa 1       wrap     }
4 gRargs.hREh"JJJJJJJJJJJJ= gWork#r;    }
4 gRargs.szUSER le isJJJJJ= *jni_cSER * Al;    }
4 gRargs.lp
     JJJJJJJJ= *jni_jvmoprin/  }
  3
4 gRargs.lp
     9JJJJJJJ= *jni_jvmoprin/ 9 }
  3
4 gRargs.dwM JJJJJJJJJJJJJ= LE JVMMS }
  3
4 gRargs.dwMxJJJJJJJJJJJJJ= LE JVMMX }
  3
4 gRargs.dwS JJJJJJJJJJJJJ= LE JVMSS }
  3
4 gRargs.bJniVf */ pJJJJJ= LE JNIVFP*INTF;    }
4 gRargs.szUSER  APX  JJJJ= *jni_rcSER ;    }
4 gRargs.szMe"\ d APX  JJJ= *jni_rme"\ d }
  3
4 gRargs.lpArgulenoES  JJJ= *jni_r     ;    }
4 gRargs.sz/issues.ap  int ig "dwrap.sz/issues.ap  in;    }
4 gRargs.sz/is
{
    int ig "dwrap.sz/is
{
    in;    }
4 gRargs.szLIBRARYle isJJJ= LE LIBPfil;     LNeSteicR derr#rtonexi
hookE lpCmdline,       mode_onexi(onf (l "ULLe;AR,ensssss
  !eStREh" "    &gRargse_Aa.
 * NeStNeSt v   4       wrapppppeSta}S .Tppen",       NU
stati"Fa}
";er-rr    REh"O)Mtci P_pGe-2
stgo
 leanup       wrap .
 * NeSteSta}S .Tppen",       NU *stderREh"Jrr   edJeeseeeer*jni_rcSER         e if (_lC- Aa.
 * NeSt  De!  Gtiver-  *ING(or HANDLIMAGEile (*LL;    /* SheSta}S .Tppen",       NU
stati"M ssL2)3Foundat 4)
#
  2ydfileNamlBl:2
st  De!Irl_t() TRUE" P_pGeOn",,,,,,,,,          e 9C3\el", V(33)
#d,i"Soundateeeee id m ssL2)3atde4)
#
  2yr n Seconds (defaults to 60)\n");
Irl_t()   int?
Irl_t()   int: L"unkn_wrO)Mtci P_pGe-2
st  *sIa 1       wrap     }
4 aMDL  Gtiver-  *ING(or LIBPfil  e (*LL;    /////
 AddLIBRARYle is(OIatdedfilt*lpWrapper->fpSionAddTole iW 
staticSO gIBPfil        wrap     }
4 eicache Sofenvironm
  dusL2)3p  
nv,d xAJVM_can Shutitrminate the arrS  InasthEnvironm
  (dfileName   eicREh"J9        c_ FALSE;nve";
be-retevia an environm
  dvari  ++ minate the a   InasthEnvironm
  9 or ,eSu
#IONS9e;     LNeSteicR dirrmt asthePS         modegWork#rt iPT_Filena- thePSy_
stati n Seconds (defaults to 60)\n");




0r, L"  --%s\n", _options[i].ssssssssssschild_callbackr, L"  --%s\n", _options[i].sssssssssssor   _jr, L"  --%s\n", _options[i].sssssssssssor tic APX_r, L"  --%s\n", _options[i].sssssssssssel", ci P_pGeOn"taMDL  Gtativer-ena'   gWork#re_Aa.
 * NeSt>fpSiona}S .Tppen",       NU
stati"Fa}
";
 
#defasthePS.O)Mtci P_pGe-2
st  *sIa 1       wrap     }
4 
  !eSt- thePSSti        ++W gWork#r, or HANDLIMAGEile (*LL;    /* SheSta}S .Tppen",       NU
stati"Fa}
";ri8aOerS*sthePS e       ++ eeeeeeeeeeeeeeeeeeee(e Apache Sof    ANDLIMAGEiMtci P_pGe-2
st v   2Mtci P_pGe-2
stgo
 leanup       wrap     }
4 eicAssemticNe         wp R6  ,       mode
  _jEh"_sri8 up- thjP7M         nArg t iPT_JEh"Cmd hiti
liz 
staticSO   /* dfilif    ANDL  /* """"mmmmd     rri8     Sf3)
  Sf3)







cO",eSu
#IONS, LE JVMMS, LE JVMMX""""mmmmd     rri8     Sf3)
  Sf3)







cO",eSSSif    ANDLdfic H, &pArg         wrap     }
4 c APXn wpriniTGelBl:nArg t iPT_    ealToA
#dW 
staticSO  ANDLdfic H, &pArg         wrap       }
4 eicPassCMDO argv 
 hild asthePS         mode
  !eSt- thePSStiC     wArg W gWork#r, or HANDLIMAGE""""mmmmd     rri8     Sf3)
  Sf3)





nArg , pArg  FFn wpriniTGelBl: v   3       wrapppppeSta}S .Tppen",       NU
stati"Fa}
";ri8aOerS*sthePS argulenoES(argc=%d)eeeeeeeeeeeeeeee(e Apache SofnArg         wrapppppgo
 leanup       wrap     }
4 eicache Sofworkrary* All        mode
  !eSt- thePSStiWorkrarle iW gWork#r, or HANDLPfil le (*LL;    ///// v   4       wrapppppeSta}S .Tppen",       NU
stati"Fa}
";ri8aOerS*sthePS workrary* All
eeeeeeeeeeeeeeeeeeee(e Apache Sof    ANDLdfil        wrapppppgo
 leanup       wrap     }
4 eicFindUcy e     cNe    hild asthePSE lpCmdline,       mode
  !eSt- thePSMt    
 gWork#re_Aa.
 * NeSt>fpS v   8           
     ni3(i  ",ilen        
stati"Fa}
";er-e     cNasthePS.O)Mtci P_pGe-2
stgo
 leanup       wrap tbf (_e if (_
   vt = 0             Sta}/* S ft(;          ULARGaiPXCMGER  , (;          
    uofnm ;    }
4 
 e
#defpid);
e,       mode
  
sid);
N in) a.
 * NeSt>fpScharfpids[32]Mtci P_pGe-2
stgsid);
ool,
e=ce
#de    y_
sid);
N in""""mmmmd     rri8     Sf3)
  Sf3)







GENERICier- theGENERICiWRIT.,"""mmmmd     rri8     Sf3)
  Sf3)







Sta}SSHAREier- ,"""mmmmd     rri8     Sf3)
  Sf3)







    i, L"  --%s\n", _options[i].szNameeeeeeeeeeeCREjU)vNEW,"""mmmmd     rri8     Sf3)
  Sf3)







Sta}SAT *IBUTE_NORMA i, L"  --%s\n", _options[i].szNameeeeeeeeeee33) appileNamlBl:2
st  Degsid);
ool,
e!= tativer-ena'  GtivUE              _SHtenv
    wr   e     *ste the a2
st  De_jni_sri8 up-, L"  --%s\n", _option_sn */ p_s(pidser*countof(pids), )32 "%d\r\neerGtic"aPper- thePSId()e;     LNeStttttttttc AP n Seconds (defaults t_sn */ p_s(pidser*countof(pids), )32 "%d\r\neereSt- thePSGtisid gWork#re_;     LNeSttttttttt(i  "
   
sid);
ool,
, pidser(     )Dispen(pids), &wrV(33) append modeeeeeeeeeFlush
  Buffert(
sid);
N in)fileName   lBl:  fOn",,,,,  fOn",,,,,.TpS   APT STAs
  T ST(&fte;     LNeSts.Low{
tJJ= ft .dwLowD#deT ST;     LNeSts.HighPULL)  ft .dwHighD#deT ST;     LNeSte.Low{
tJJ= fte.dwLowD#deT ST;     LNeSte.HighPULL)  fte.dwHighD#deT ST;     LNeStnm )  (     )((e.QuadPULL)-ts.QuadPULL) / 10000 appeeeeeeeeL"Ea}S .Tppen",       NUINFOta l_t()M     edJ   L" m
 isrm lo eee nm         e if (_optionsrv#de leanup:zVOn",-2  !  Gtativer-ena'   gWork#re_ppeeeeeeeeL"EClosPool,
 gWork#re;eeeeeicelosPoatde ork#rtO_LOGR ,       gWork#rt i = 0;
    optionsrv#de
\n"eicSl_t()M    roctO_LOGRrNE l,   
   WINAPIerl_t()_cisp_O_LOGRr(        cispC dr    GET_OL
    utt);dId }
  3(0)
#d  PrTh);dappileNamswitch    ctrlCRUE"""""mmmmd   ce:\ncess maiCONTROL; HUTDOWN:          
     ni3(i  ",ilen        INFOta l_t()M HUTDOWN signdUlrv2ydfileName   ce:\ncess maiCONTROL; TOP:ileNamlBl:2
st  DeLL;    /* Shute>ieFFn wpriniTGelBl:2
st rrort",     S if ((cess maiHAOP_    ING, NO_Estat
#LL;    /* Shute, 1000)fileName   lBl:  fOn",,,,,NeSte APXn wpriniTGelBl:2
st rrort",     S if ((cess maiHAOP_    ING, NO_Estat
#3e, 1000)fileName   lBl:  fOn",,,,,NeSteicStProatderl_t()Masynchronouslte,lpWrapper->fpSt  PrTh);de=ce
#deTh);d(33)
#d,, L"  --%s\n", _options[i].szNameeeeeeeerl_t() "_w,, L"  --%s\n", _options[i].szNameeeeeeee LPVOID)cess maiCONTROL;    r, L"  --%s\n", _options[i].sssssssssssss0, &tt);dId)fileName   lBl:ClosPool,
   PrTh);d)Mtci P_pGe-2
st  *sIafileName   ce:\ncess maiCONTROL;PXCMDROGjU):tci P_pGe-2
st  rort",     S if (E(rvice R*stderTRAC.,"""mmmmd     rri8     Sf3)
  Sf3) rl_t()   if (.  c"aPperSpen(,"""mmmmd     rri8     Sf3)
  Sf3) rl_t()   if (.  W  32f (lC drr n Seconds (defaults to 60)\n");
 rl_t()   if (.  WaitHinLr n Seconds (defaults to 60)\n");
0)fileName   lBl:  *sIafileName   default:tci P_pGe-2
stename) {
 }de
\n"eicConsolM    roctO_LOGRrNE l,   WrappWINAPIeconsol_O_LOGRr(        cisp }
    GET_OLswitch    ctrl }
 """"mmmmd   ce:\nCTRL_BREj  
VENT:          
     ni3(i  ",ilen        INFOtaConsolMCTRL+BREj oe
  esigndUrv2ydfileNamlBl:2
st  *sIa el",        d   ce:\nCTRL_C 
VENT:          
     ni3(i  ",ilen        INFOtaConsolMCTRL+Coe
  esigndUrv2ydfileNamlBl:2
strl_t() "_w  LPVOID)cess maiCONTROL;    dfileNamlBl:2
st  *sIa ice as consWLIce:\nCTRL_C OSr 
VENT:          
     ni3(i  ",ilen        INFOtaConsolMCTRL+C OSrte
  esigndUrv2ydfileNamlBl:2
strl_t() "_w  LPVOID)cess maiCONTROL;    dfileNamlBl:2
st  *sIa ice as consWLIce:\nCTRL_ HUTDOWN 
VENT:          
     ni3(i  ",ilen        INFOtaConsolM HUTDOWN e
  esigndUrv2ydfileNamlBl:2
strl_t() "_w  LPVOID)cess maiCONTROL; HUTDOWN fileNamlBl:2
st  *sIa ice as consWLIce:\nCTRL_n  OFF 
VENT:          
     ni3(i  ",ilen        INFOtaConsolMn  OFF e
  esigndUrv2ydfileNamlBl:2
st  De!Irl_t() TRUE"Xn wpriniTGelBl:2
strl_t() "_w  LPVOID)cess maiCONTROL;    dfileNamlBl:2
st}ileNamlBl:2
st  *sIa ice as consWLIename) { {
 }de st  *sIa el",    
\n"eicMainaFoundateex    eon loop.l,   
   WINAPIerl_t()Main(      argczStdTh"Jv*argv    GET_OL
    rc   e     *s rl_t()   if (.   ,      }
 )))))  cess maiWIN32_OWN_PRO APX     *s rl_t()   if (.  c"aPperSpen(t )))  cess maiHANDL_    ING     *s rl_t()   if (.  c ptrocsAchep d"   cess maiCONTROL;PXCMDROGjU)     *s rl_t()   if (.  W  32f (lC drt)))  e     *s rl_t()   if (.  c    PoipWr )))))  e     *s rl_t()   if (.  WaitHinLtttttt)))  e     *s rl_t()   if (.   ,     S      cf (lC drt i0         eSta}S .Tppen",       NU *stderIhmide;rl_t()Main()i.2ydfilileNam-2    Gtiver-  *ING(Irl_t()   inC_Aa.
 * NeSt, L"  en[SIZ_HUGLEN]           ET_OP;          PSECURITYSAT *IBUTES sat i.TpNullACL(dfileName   ication\n"en,STIZ_DESLENwpL"Global\\"dfileName   icatioay ten,STIZ_DESLENwpIrl_t()   inCfileName   icatioay ten,STIZ_DESLENwpServicSIGNA append mode  setPTas7p i <ulDispen ten)p i, 0&}
    }
     -2  en[i]t = L' '-, L"  --%s\n", _open[i]t  L'_'fileNamlBl:2
stc AP n Seconds (defaulen[i]t  towuppRr(en[i]        wrap     }
4 gSigndUE
  t ie
#deE
  W(sa
#tderr el", V(e6         :D CleanNullACL( 
   *)sa appileNamlBl:
  gSigndUE
  _Aa.
 * NeSttttt
    tidfileNamlBl:2
stgSigndUTh);de=ce
#deTh);d(33)
#d, e
  Th);d, 33)
#d, &tid     els else if (_e if (_eicC     atdeS    MRUE         aMDL  Gtiver-  *ING(or HANDLMODEile ileNamlBl:
  !tderr, L"         MODEwpServicJVMe_Aa.
 * NeSt>fpS_jni_sri8 up)  ice as consWLIwrapaMDL  Gtiver-  *ING(or HANDL  /* )              _SHtenv*jni_rcSER ))  WideToANSI(or HANDL  /* )append modeeeeeeeeeeicMtnhangrdUcrdot; L"\ sSERhe  *lpWrapper->fpStttttrrStrCharRer
7MA(*jni_rcSER , '.', '/')fileName   lBl:  fOn",,,,,NeSte APXn wpriniTGelBl:2
steicPresumutits maina*lpWrapper->fpSttttt*jni_rcSER )  WideToANSI(L"MainydfileNamlBl:2
st  fOn",,,,,tttt*jni_r     e=ULL;  NDLdfic H       wrap     }
4 c APX
  !tderr, L"         MODEwpServicJAVA)              _SHPREh"Jvjxt i = 0, szJHJ= LE JAVAHOMEfileNamlBl:2
st  De!szJH-, L"  --%s\n", _opszJHJ= }R
  REh" oftHom 
staticel", ci P_pGeOn",,,,,c APX
  !tderr, L" szJHwpServicJDK)              _SHtenv
 FranMe _INDMDO JDKcREh"Homa*lpWrapper->fpStttttszJHJ= }R
  REh" oftHom 
staticel", ci P_pGeOn",,,,,  fOn",,,,,,,,,c APXCMDL!tderr, L" szJHwpServicJREile (*LL;    /* Shtenv
 FranMe _INDMDO JREcREh"Homa*lpWrapper->fpStttttszJHJ= }R
  REh" oftHom 
staticice  ;    }
4 ,,,,  fOn",,,,,,,,,CMDLszJH-e (*LL;    /* Shtenvjxt ieSt-tatAlloc 
static(lDispen tszJH-e+ 16)e,  izeof(, L" e_;     LNeSttttttttttderrn\n"jx, szJH_;     LNeSttttttttttderray tjx, ServicJBIN fileNamlBl:2
st,,,,CMDL!or HANDLdfil 8 (*LL;    /* Shtenvtenv
 UsPoJAVA_HOME/btiddlsrrULL)* All        modeeeeeeeeeeeeePREh"JvszJPt ieSt-tatAlloc 
static(lDispen tszJH-e+ 8)e,  izeof(, L" e_;     LNeSttttttttttttttderrn\n"szJP, szJH_;     LNeSttttttttttttttderray tszJP, ServicPBIN fileNamlBl:2
st,,,,,,,,or HANDLdfilt iszJPfileNamlBl:2
st,,,,gPidfileName   gPidfileNammmmmc APXn wpriniTGelBl:2
st    _pGelp)
     SbDC_p
stati"Un,ticNer-findcREh"JRunt ST Environm
  2ydfileName   lBl:2
stgo
 leanup       wrape   gPidfileNammmmm_jEh"_sri8 up)  ice as consWLIwrapeicSti8 4)
# nowM    ainsCMDO fuliy* All
MDO jEh".ex e,lpWrapper->fpStSr HANDLIMAGE)  jx    els else if (_e if (_eicC     atdeS opMRUE         aMDL  Gtiver-  *ING(or HAOPMODEile ileNamlBl:
  !tderr, L"      OPMODEwpServicJVMe_Aa.
 * NeSt>fpS_jni_shu%d_wro  ice as consWLIwrapaMDL  Gtiver-  *ING(or HAOP  /* )              _SHtenv*jni_scSER )  WideToANSI(or HAOP  /* )fileName   lBl:2
strrStrCharRer
7MA(*jni_scSER , '.', '/')fileName   lBl:  fOn",,,,,NeSte APXn wpriniTGelBl:2
steicDefaulter(OIMaina*lpWrapper->fpSttttt*jni_scSER )  WideToANSI(L"MainydfileNamlBl:2
st  fOn",,,,,tttt*jni_s     e=ULL;  OPatic H       wrap     }
4 c APX
  !tderr, L"      OPMODEwpServicJAVA)              _SHPREh"Jvjxt i = 0, szJHJ= LE JAVAHOMEfileNamlBl:2
st  De!szJH-, L"  --%s\n", _opszJHJ= }R
  REh" oftHom 
staticel", ci P_pGeOn",,,,,c APX
  !tderr, L" szJHwpServicJDK)              _SHtenv
 FranMe _INDMDO JDKcREh"Homa*lpWrapper->fpSt _opszJHJ= }R
  REh" oftHom 
staticel", ci P_pGeOn",,,,,  fOn",,,,,,,,,c APXCMDL!tderr, L" szJHwpServicJREile (*LL;    /* Shtenv
 FranMe _INDMDO JREcREh"Homa*lpWrapper->fpStttttszJHJ= }R
  REh" oftHom 
staticice  ;    }
4 ,,,,  fOn",,,,,,,,,CMDLszJH-e (*LL;    /* Shtenvjxt ieSt-tatAlloc 
static(lDispen tszJH-e+ 16)e,  izeof(, L" e_;     LNeSttttttttttderrn\n"jx, szJH_;     LNeSttttttttttderray tjx, ServicJBIN fileNamlBl:2
st,,,,CMDL!or HAOPPfil 8 (*LL;    /* ShtenvtenvPREh"JvszJPt ieSt-tatAlloc 
static(lDispen tszJH-e+ 8)e,  izeof(, L" e_;     LNeSttttttttttttttderrn\n"szJP, szJH_;     LNeSttttttttttttttderray tszJP, ServicPBIN fileNamlBl:2
st,,,,,,,,
 UsPoJAVA_HOME/btiddlsrrPro* All        modeeeeeeeeeeeeeor HAOPPfilt iszJPfileNamlBl:2
st,,,,gPidfileName   gPidfileNammmmmc APXn wpriniTGelBl:2
st    _pGelp)
     SbDC_p
stati"Un,ticNer-findcREh"JRunt ST Environm
  2ydfileName   lBl:2
stgo
 leanup       wrape   gPidfileNammmmm_jEh"_shu%d_wro  ice as consWLIwrapeicStPr4)
# nowM    ainsCMDO fuliy* All
MDO jEh".ex e,lpWrapper->fpStSr HAOPIMAGE)  jx    els else if (_e if (_eicFindce    SER * Ald       L  De_jni_shu%d_wr || _jni_sri8 up- thjP7M       De  Gtiver-  *ING(or ,eSile (*LL;    /* ShCMDLtderr, W(or ,eSp Service\n")stdout, NULL, _IONB*jni_jvm* AlJ= LE JVM       wrap     }
4   De  Gtiver-  *ING(or   /* dfil)stdout, NULL, _*jni_cSER * Al)  WideToANSI(or   /* dfil);    }
4   De  Gtiver-  *ING(or      METHOD)stdout, NULL,  *jni_rme"\ d ))  WideToANSI(or HANDLMETHOD);    }
4   De  Gtiver-  *ING(or   OPMETHOD)stdout, NULL,  *jni_sme"\ d ))  WideToANSI(or HAOPMETHOD);    }
4 *jni_jvmoprin/   ))  MzWideToANSI(or ,eSu
#IONS        wrap*jni_jvmoprin/ 9 ))  MzWideToANSI(or ,eSu
#IONS9e;     Le if (_
  Irl_t() TRUE"Xn wpriniTGeeicR derr#rt l_t()MC   roctO_LOGRre,       mode_rl_t()   if (_O_LOGR)  R derr#r l_t()ctrlool,
rW(Irl_t()   ini, L"  --%s\n", _options[i].szNameeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeerl_t()_cisp_O_LOGRrci P_pGeOn"taMDL  Gtativer-ena'    rl_t()   if (_O_LOGR _Aa.
 * NeSt>fpSiona}S .Tppen",       NU
stati"Fa}
";
r derr#rt l_t()MC   roctfoA eeeeeeeeeeeeeeeeeeee(e Apache SofIrl_t()   inCfileName       go
 leanup       wrap     }
4 eicAllocen(tconsold xAthaL)e
  s ge s asthePS
";*lpWrapper->CMDL!AttachConsol(ATTACH2atiENT_PRO APX 8&&eeeeeeeeeeeee(eG      NULL,  /* i
 * Netativer-ena'  _Aa.
 * NeSt>fpSHWND hcfileName       AllocConsol(dfileNamlBl:2
st  De(hct i.TpConsolW     ())    33) eeeeeeeeeeeee(e ApShowW     (hc, SW_HID  ;    }
4 e if (_e if (_oprort",     S if ((cess maiHANDL_    ING, NO_Estat
#3000)fileNam  De(rc   rl_t() "      /* ieFFn wpriniTGeeicSl_t()Mid rr   ede, BOOL isHel  rort",     S if ((cess maiRUNNING, NO_Estat
#0 appeeeeeeeeL"Ea}S .Tppen",       NUGelBl: Waite   DCptwork#rtExAlinish2.2ydfileName   eicacheconsoldO_LOGRre
 ap*sI nCTRL)e
  s , BOOL isHelSTpConsolctrlool,
r((Pena'  R_ROUTINE)consol_O_LOGRricice  ;  ppeeeeeeeeL"Eool,
Wait gWork#r, INFINIT., el", ci P_pGeOn",rr
      staf (!chemas-GelBl: Work#rtlinishrv2ydfileName if (_lC- Aa.
 * NeSteSta}S .Tppen",       NU
stati"Sl_t() "   t  *sIaeden"eeerrc_       whilgo
 leanup       e if (_
  gShu%d_wrE
  FFn wileName   eicEnsupeCMDattshu%d_wroat);dexis beDCpeCusrminate the arra}S .Tppen",       NUGelBl: Waite   DCptShu%d_wrE
  2ydfileName     rort",     S if ((cess maiHAOP_    ING, NO_Estat
#ONE_MINUT ci P_pGeOn",WaitForSL2)GRObjecLegShu%d_wrE
  
#ONE_MINUT ci P_pGeOn",eSta}S .Tppen",       NU *stderrhu%d_wrE
  esigndUrv2ydfileNamlBl:ClosPool,
 gShu%d_wrE
  F    elswhilgShu%d_wrE
  e=c = 0;
ileName   eicTeid ,
  c ShutExAw
  ileNadUcrat);ds;er-e iteeeeeeeeeeeminate the arra}S .Tppen",       NUGelBl: Waite   1 min  cNleNadUcrat);ds;er-e it2ydfileName     rort",     S if ((cess maiHAOP_    ING, NO_Estat
#ONE_MINUT ci P_pGeOn",    ederoyJvm(ONE_MINUT ci P_pGee if (_lC- Aa.
 * NeSt
 (tc inttdr  L"\    shu%d_wroe
  eeeeeeeeeeem Pstbably bec Shutmain()t  *sIaede L"\    ensuporeaUcrat);dseeeeeeeeeeem hav(tlinishrveeeeeeeeeeeminate the arra}S .Tppen",       NUGelBl: Waite   leNadUcrat);ds;er-e it2ydfileName       ederoyJvm(INFINIT.dfileName     rort",     S if ((cess maiHAOP_    ING, NO_Estat
#      else if (_    _pGelp)
     SbDC_pGelBl: JVM_dederoyrv2ydfileNam  rort",     S if (StPrpov(}R
  Vmf (lC dr()e;  ileNam  *sIafil leanup:zVOn",eiceleanup
minate t  rort",     S if (StPrpov(rc_       gf (lvale=crc;ileNam  *sIafileNamUNREFERENCED2atic ETER(argc)fileNamUNREFERENCED2atic ETER(argv)fil
\n"n"eicRunoatderl_t()MinoatdedebugoTRUE.l,   WrappdocmdDebug",     (LP     aTbhd
i8     G2    GET_OLIrl_t() TRUE   el",        Irl_t()   int=
i8     G2.1tatiNX=n+4 L"; if (_    _pGelp)
     SbDC_pINFOtaDebugge   eeee Foundati.2ywpIrl_t()   inCfileNamrl_t()Main(0V(33) append     _pGelp)
     SbDC_pINFOtaDebugerl_t()Mlinishrv L"\ exi
  dr n"eeergf (lval append SAFE_C OSr ena'   gsid);
ool,
dfileNam
  gsid);
N in) a.
 * NeSttbasea    y_
sid);
N in)    else if (_  *sIa gf (lvale= ie ?cice  : el",    
\n"WrappdocmdRun",     (LP     aTbhd
i8     G2    GET_OL   lstvappend Sess maiTABLE_ENTRYW di * Ach_   ++[]t  a.
 * NeSt{
i8     G2.1tatiNX=n+4 L",e LPSess maiMAIN_FUNC#IONW)rl_t()Main },.
 * NeSt{
 = 0,  = 0 e if (_e       Irl_t() TRUE   ice as consIrl_t()   int=
i8     G2.1tatiNX=n+4 L"; if (_    _pGelp)
     SbDC_pINFOtaRONn 2)cSl_t()Meeeee.2ywpIrl_t()   inCfileNam  DeL"    l_t()ctrlDi * Ach
rW(di * Ach_   ++e_Aa.
 * NeSteSta}S .Tppen",       NUINFOtaRunorl_t()Mlinishrv2ydfileName    v)  [i].szVOn",e if (_lC- Aa.
 * NeSteSta}S .Tppen",       NU
stati"S"    l_t()ctrlDi * Ach
rtfoA eeee3fa}
".eeeeeeeeeeeeeee(e Apachey_
stati37 -- Service R6    eName    v)  el",        }ppend SAFE_C OSr ena'   gsid);
ool,
dfileNam
  gsid);
N in) a.
 * NeSttbasea    y_
sid);
N in)    else if (_  *sIa rv#de
\n" *stderconstScharf*gSz- th[]t  a.
 * "eeeeeeee"pars        wp R6  argulenoEeeeeeeee"estnrconfranMce R6eeeeeeee"runorl_t()MaseconsoldaService R6eeeeeeee"runorl_t()eeeeeeee"rrULL)rl_t()eeeeeeee"rrop)rl_t()eeeeeeee"upd#defsl_t()M*      :DEeeeeeeee"timodUcrrl_t()eeeeeeee"dbasea3rl_t()eeeeeeee = 0de;  il
   __cdecltmain(ET_OargczScharf**argv    GET_OLUPXC rv   e   GET_OLLP     aTbhd
i8     G2;ilileNam-2  argc > 1) a.
 * NeStt     rs   e     *ste tCMDLstrncmp(argv[1], "//PPywp4 /* ieFFn wpriniTGelBl:eicool,y sleep ro  e cNdefaultraryExA1 min  cN*lpWrapper->fpSt-2  argv[1][4])&& argv[1][5])&& argv[1][6] 8 (*LL;    /* Shtenvi  dust ietoi argv[1] + 6 fileNamlBl:2
st,,,,CMDLust>ieFeeeeeeeeeeeee(e Apaches )  (     )usfileNamlBl:2
stgPidfileNammmmmSleep(PS   1000)fileName   lBl:f (l- thePS(0)fileName   lBl:  *sIafileName        }
4 c APX
  derr, (argv[1], "p Shu" /* ieFFn wpriniTGelBl:eicool,y sleep ro  e cNdefaultraryExA1 min  cN*lpWrapper->fpSt-2  argc > 2 8 (*LL;    /* Shtenvi  dust ietoi argv[2] fileNamlBl:2
st,,,,CMDLust>ieFeeeeeeeeeeeee(e Apaches )  (     )usfileNamlBl:2
stgPidfileNam     }
4   Dess 8 (*LL;    /* ShSleep(PS   1000)fileName   lBl:f (l- thePS(0)fileName   lBl:  *sIafileName        }e if (_   ool,
Manager hiti
liz )fileNameice
#defMDO mainastat ,       gstat  ieSt-tate
#de(33)
#de;  ileNameicParscNe         wp R6  ,         De(i8     G2t iPT_F    G2Parsc>szStdEr*oprin/ er*co    w er*altcmds  /* i33) Aa.
 * NeSteSta}S .Tppen",       NU
stati"Invath,      wp R6  argulenoE2ydfileName    v)  1       wrapgo
 leanup       e if (_PT_F    G2LstnEnvVars(i8     G2dfileNam
  y_
stati37 dwCmd hdex < 6 e ileNamlBl:
  !tstnConfranMce R6(i8     G2d8&&eeeeeeeeeeeee(y_
stati37 dwCmd hdex < 5_Aa.
 * NeSt>fpSiona}S .Tppen",       NU
stati"LstnrconfranMce R63fa}
".eiMtci P_pGe-2
st v   2Mtci P_pGe-2
stgo
 leanup       wrap     }}        L"Ea}SOpen 
staticSO gPidfilifor gPidREFIXifor gPiROTAT.dfileNamL"Ea}SLe
lStiW(33)
#or gPi*stde append     _pGelp)
     SbDC_pGelBl: Apach
 C   n/  Dae n/ asthrunolog;ihiti
lizv2ydfileNam
  or gPiROTAT.dnate the arra}S .Tppen",       NUGelBl: a}S ,
  ropen(tiachd%";rim lo eee or gPiROTAT.dfil if (_    _pGelp)
     SbDC_pINFOtaApach
 C   n/  Dae n/ asthruno(%sd%"-bit) rr   ed.eeeeeeeeeeeeeee(e ApPRG_VERSION,pPRG_BITSdfil if (_AplZeroMe nry &gS"dwrap,  izeof(
  iHADWRAPe_;     Lg "   P Alt=
i8     G2.1taExeP Al;    }g "dwrap.sz _pP AlJ= LE gPidfilfileNameicOtismr dirrmt whenorONn 2)caseafsl_t()M,         Dey_
stati37 dwCmd hdex * i2 8 (*LL;    /g "dwrap.sz/is
{
    ine=ULL;  DOUTPUT;(*LL;    /g "dwrap.sz/issues.ap  int iLL;  D
stat    else if (_  dirrmt/isS%);
  &gS"dwrap, i8     G2dfileNam
  y_
stati37 dwCmd hdex * i2 8 (*LL;    /SYSTEM/* S t;(*LL;    /G   ocalT ST(& F    elswhilf */ p( %d_IN, "\n%"-%02"-%02" %02":%02":%02" "eeeeeeeeeeeee(e ApppppppppaApach
 C   n/  Dae n/ asthruno       ihiti
lizv2\neeeeeeeeeeeeeee(e Apache Soft.wYear, t.wMonAl,_t.wDayeeeeeeeeeeeeee(e Apache Soft.wHour, t.wMin  c, t.wSim loF    elswhilf */ p( %derr, "\n%"-%02"-%02" %02":%02":%02" "eeeeeeeeeeeee(e ApppppppppaApach
 C   n/  Dae n/ asthruno   \n",ihiti
lizv2\neeeeeeeeeeeeeee(e Apache Soft.wYear, t.wMonAl,_t.wDayeeeeeeeeeeeeee(e Apache Soft.wHour, t.wMin  c, t.wSim loF    else if (_switch  y_
stati37 dwCmd hdex """"mmmmd   ce:\n1: eicRunoSl_t()MaseconsoldaService R6 *lpWrapper->fpSt-2  !docmdDebug",     (i8     G2dFeeeeeeeeeeeee(e Ap v   3       wrapename) {
 md   ce:\n2: eicRunoSl_t()M*lpWrapper->fpSt-2  !docmdRun",     (i8     G2dFeeeeeeeeeeeee(e Ap v   4       wrapename) {
 md   ce:\n3:peic